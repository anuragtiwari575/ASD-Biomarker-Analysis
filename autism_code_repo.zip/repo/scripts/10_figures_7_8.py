# -*- coding: utf-8 -*-
"""
step6b_fix_figs.py - regenerates ONLY fig7 and fig8, fixing two defects in
the step6 output:

  fig7: matplotlib was drawing imshow's default half-integer ticks
        (-0.5, 0.0, 0.5, ...) instead of the patch indices 0-3.
  fig8: panel (c) was an uninformative 2x16 strip (leftover dead code).
        It is now two proper 4x4 hemisphere maps on a shared colour scale,
        which is what the caption actually promises.

Everything else (fig5, fig6, fig9) is already correct - do not re-run step6.

RUN:  python step6b_fix_figs.py > figfix.txt 2>&1
Then copy fig7.png and fig8.png into latex/figures/, overwriting.
"""

import os
import sys
from pathlib import Path

import numpy as np
from scipy import stats

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Path to the extracted feature file. Override without editing this script:
#   Linux/macOS:  export ABIDE_FEATURES=/path/to/features_full3d_64patches.npz
#   Windows:      set ABIDE_FEATURES=C:\path\to\features_full3d_64patches.npz
NYU_PATH = os.environ.get(
    "ABIDE_FEATURES",
    "features/features_full3d_64patches.npz",
)
DPI = 600


def load(path):
    z = np.load(path, allow_pickle=True)
    X = y = None
    for k in z.files:
        a = np.asarray(z[k])
        if a.ndim == 2 and 512 in a.shape:
            X = a if a.shape[1] == 512 else a.T
    for k in z.files:
        a = np.asarray(z[k]).ravel()
        if X is not None and a.size == X.shape[0] and len(np.unique(a)) == 2:
            y = a
    u = np.unique(y)
    y = (y == u.max()).astype(int)
    if (y == 1).sum() != 79 and (y == 0).sum() == 79:
        y = 1 - y
    return X.astype(float), y


def patch_d(X, y):
    a, b = X[y == 1], X[y == 0]
    sp = np.sqrt((a.var(0, ddof=1) + b.var(0, ddof=1)) / 2.0)
    sp[sp == 0] = 1e-12
    d = np.abs(a.mean(0) - b.mean(0)) / sp
    return np.array([np.nanmax(d[8 * p:8 * p + 8]) for p in range(64)])


def fig7(dvals, out):
    cube = np.zeros((4, 4, 4))
    for p in range(64):
        cube[p // 16, (p % 16) // 4, p % 4] = dvals[p]

    fig, ax = plt.subplots(1, 3, figsize=(13.5, 4.2))
    panels = [
        ("Sagittal (mean over $k$)", cube.mean(2), "$j$ (posterior$\\rightarrow$anterior)", "$i$", False),
        ("Coronal (mean over $j$)", cube.mean(1), "$k$ (left$\\rightarrow$right)", "$i$", True),
        ("Axial (mean over $i$)", cube.mean(0), "$k$ (left$\\rightarrow$right)", "$j$", True),
    ]
    for a, (t, m, xl, yl, divider) in zip(ax, panels):
        im = a.imshow(m, cmap="RdYlBu_r")
        a.set_title(t, fontsize=11)
        a.set_xlabel(xl); a.set_ylabel(yl)
        a.set_xticks(range(4)); a.set_xticklabels(range(4))   # <- the fix
        a.set_yticks(range(4)); a.set_yticklabels(range(4))
        for r in range(4):
            for c in range(4):
                a.text(c, r, "%.2f" % m[r, c], ha="center", va="center",
                       fontsize=7.5,
                       color="w" if m[r, c] > m.max() * .72 else "k")
        if divider:
            a.axvline(1.5, color="k", lw=2.5)
        fig.colorbar(im, ax=a, shrink=.85, label="Mean Cohen's $d$")
    fig.tight_layout()
    fig.savefig(out, dpi=DPI)
    plt.close(fig)
    print("  wrote fig7.png (integer ticks + cell values)")


def fig8(dvals, out):
    L, R, pair_ij = [], [], []
    for i in range(4):
        for j in range(4):
            b = 16 * i + 4 * j
            L.append(max(dvals[b], dvals[b + 1]))
            R.append(max(dvals[b + 2], dvals[b + 3]))
            pair_ij.append((i, j))
    L, R = np.array(L), np.array(R)
    W, p = stats.wilcoxon(R, L, alternative="greater")
    li = (R - L) / (R + L + 1e-8)

    fig = plt.figure(figsize=(11.5, 8.8))
    gs = fig.add_gridspec(2, 3, width_ratios=[1.15, 1, 1], hspace=.32, wspace=.34)

    # (a) paired comparison
    a0 = fig.add_subplot(gs[0, 0])
    for n in range(16):
        a0.plot([0, 1], [L[n], R[n]], "-o", ms=4.5,
                color="#c1121f" if R[n] > L[n] else "#4a6fa5", alpha=.8)
    a0.set_xlim(-.25, 1.25); a0.set_xticks([0, 1])
    a0.set_xticklabels(["Left", "Right"])
    a0.set_ylabel("Max Cohen's $d$ in pair")
    a0.set_title("(a) Paired L-R comparison\n%d/16 right-dominant, $W=%d$, $p=%.4f$"
                 % ((R > L).sum(), W, p), fontsize=10)

    # (b) laterality index
    a1 = fig.add_subplot(gs[0, 1])
    a1.hist(li, bins=10, color="#1d4e89", edgecolor="w")
    a1.axvline(0, color="k", ls="--")
    a1.set_xlabel("Laterality index"); a1.set_ylabel("Count")
    a1.set_title("(b) Laterality index\n(positive = right-dominant)", fontsize=10)

    # (d) boxplot
    a2 = fig.add_subplot(gs[0, 2])
    bp = a2.boxplot([L, R], tick_labels=["Left", "Right"], patch_artist=True)
    for patch, c in zip(bp["boxes"], ["#4a6fa5", "#c1121f"]):
        patch.set_facecolor(c); patch.set_alpha(.65)
    a2.set_ylabel("Max Cohen's $d$")
    a2.set_title("(c) Effect size by hemisphere\nmean %.3f vs %.3f (%.2f$\\times$)"
                 % (L.mean(), R.mean(), R.mean() / L.mean()), fontsize=10)

    # (d)/(e) proper 4x4 hemisphere maps on a shared scale
    vmax = max(L.max(), R.max())
    for col, (vals, name) in enumerate(((L, "Left"), (R, "Right"))):
        ax = fig.add_subplot(gs[1, col])
        grid = vals.reshape(4, 4)
        im = ax.imshow(grid, cmap="RdYlBu_r", vmin=0, vmax=vmax)
        for r in range(4):
            for c in range(4):
                ax.text(c, r, "%.2f" % grid[r, c], ha="center", va="center",
                        fontsize=8,
                        color="w" if grid[r, c] > vmax * .72 else "k")
        ax.set_xticks(range(4)); ax.set_yticks(range(4))
        ax.set_xlabel("$j$"); ax.set_ylabel("$i$")
        ax.set_title("(%s) %s hemisphere" % ("de"[col], name), fontsize=10)
    cax = fig.add_subplot(gs[1, 2])
    diff = (R - L).reshape(4, 4)
    lim = np.abs(diff).max()
    im2 = cax.imshow(diff, cmap="RdBu_r", vmin=-lim, vmax=lim)
    for r in range(4):
        for c in range(4):
            cax.text(c, r, "%+.2f" % diff[r, c], ha="center", va="center",
                     fontsize=8)
    cax.set_xticks(range(4)); cax.set_yticks(range(4))
    cax.set_xlabel("$j$"); cax.set_ylabel("$i$")
    cax.set_title("(f) Right $-$ Left difference", fontsize=10)
    fig.colorbar(im2, ax=cax, shrink=.8)

    fig.savefig(out, dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    print("  wrote fig8.png (W=%d, p=%.4f, %d/16, ratio %.2f)"
          % (W, p, (R > L).sum(), R.mean() / L.mean()))


def main():
    p = Path(NYU_PATH)
    if not p.exists():
        hits = list(Path.home().rglob("features_full3d_64patches.npz"))
        if not hits:
            print("[FATAL] features not found; edit NYU_PATH."); sys.exit(1)
        p = hits[0]
    X, y = load(p)
    d = patch_d(X, y)
    fig7(d, Path("fig7.png"))
    fig8(d, Path("fig8.png"))
    print("\nCopy both into latex/figures/, overwriting the old versions.")


if __name__ == "__main__":
    main()
