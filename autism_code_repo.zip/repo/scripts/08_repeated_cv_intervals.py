# -*- coding: utf-8 -*-
"""
step10_repeated_cv_ci.py - computes the replacement confidence intervals.

BACKGROUND
  step9 showed the published CI [64.0, 80.5] is the NAIVE bootstrap: copies
  of the same subject were allowed to fall in both the training and test
  folds, which inflates resampled accuracy. That interval cannot be kept.

  But the subject-grouped bootstrap ([43.1, 68.9]) is not the right
  replacement either. A bootstrap resample of 184 subjects contains only
  about 116 unique subjects, so grouped CV trains on far fewer distinct
  people than the actual analysis does; its mean of 56% is biased DOWNWARD
  for the same reason the naive one is biased upward.

  The clean interval for a cross-validated estimate is a REPEATED
  CROSS-VALIDATION interval: repeat the entire 10-fold procedure R times
  with different partitions, keeping all 184 subjects every time, and take
  the percentile interval of the R mean accuracies. It measures the
  quantity actually reported (the mean CV score), is centred on it, and
  involves no duplicated subjects at all.

  This script computes that interval for every metric in Table 2, and also
  re-prints the grouped-bootstrap interval so you can report it as a
  conservative sensitivity bound.

RUN:  python step10_repeated_cv_ci.py > ci.txt 2>&1
      (R = 200 repetitions x 10 folds = 2000 fits; a few minutes)
"""

import os
import sys
from pathlib import Path

import numpy as np

# Path to the extracted feature file. Override without editing this script:
#   Linux/macOS:  export ABIDE_FEATURES=/path/to/features_full3d_64patches.npz
#   Windows:      set ABIDE_FEATURES=C:\path\to\features_full3d_64patches.npz
NYU_PATH = os.environ.get(
    "ABIDE_FEATURES",
    "features/features_full3d_64patches.npz",
)
K, M, R = 50, 10, 200
BAR = "=" * 72


def load(path):
    z = np.load(path, allow_pickle=True)
    X = y = None
    for k in z.files:
        a = np.asarray(z[k])
        if a.ndim == 2 and 512 in a.shape:
            X = a if a.shape[1] == 512 else a.T
    for k in z.files:
        a = np.asarray(z[k]).ravel()
        if X is not None and a.size == X.shape[0] and len(np.unique(a)) == 2:
            y = a
    u = np.unique(y)
    y = (y == u.max()).astype(int)
    if (y == 1).sum() != 79 and (y == 0).sum() == 79:
        y = 1 - y
    return X.astype(float), y


def cohens_d(X, y):
    a, b = X[y == 1], X[y == 0]
    sp = np.sqrt((a.var(0, ddof=1) + b.var(0, ddof=1)) / 2.0)
    sp[sp == 0] = 1e-12
    return np.abs(a.mean(0) - b.mean(0)) / sp


def one_cv(X, y, seed):
    from sklearn.model_selection import StratifiedKFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.svm import SVC
    from sklearn.metrics import (f1_score, roc_auc_score, precision_score,
                                 recall_score)
    acc, auc, f1, pre, rec = [], [], [], [], []
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=seed)
    for tr, te in skf.split(X, y):
        d = cohens_d(X[tr], y[tr])
        top = np.argsort(-d)[:K]
        sc = StandardScaler().fit(X[tr][:, top])
        Ztr, Zte = sc.transform(X[tr][:, top]), sc.transform(X[te][:, top])
        clf = SVC(kernel="linear", C=0.5, class_weight="balanced").fit(Ztr, y[tr])
        pred = clf.predict(Zte)
        acc.append((pred == y[te]).mean())
        f1.append(f1_score(y[te], pred, zero_division=0))
        pre.append(precision_score(y[te], pred, zero_division=0))
        rec.append(recall_score(y[te], pred, zero_division=0))
        auc.append(roc_auc_score(y[te], clf.decision_function(Zte)))
    return (np.mean(acc), np.mean(auc), np.mean(f1),
            np.mean(pre), np.mean(rec))


def main():
    print(BAR)
    print("STEP 10 - REPEATED-CV CONFIDENCE INTERVALS (R = %d)" % R)
    print(BAR)
    p = Path(NYU_PATH)
    if not p.exists():
        hits = list(Path.home().rglob("features_full3d_64patches.npz"))
        if not hits:
            print("[FATAL] features not found; edit NYU_PATH."); sys.exit(1)
        p = hits[0]
    X, y = load(p)
    print("  data: %s | ASD %d | HC %d" % (X.shape, (y == 1).sum(), (y == 0).sum()))

    base = one_cv(X, y, 42)
    print("  seed-42 point estimates: acc %.4f | auc %.4f | f1 %.4f | "
          "prec %.4f | rec %.4f\n" % base)

    out = []
    for rep in range(R):
        out.append(one_cv(X, y, rep))
        if (rep + 1) % 50 == 0:
            print("  ... %d/%d repetitions" % (rep + 1, R))
    out = np.array(out)

    names = ["Accuracy", "AUC", "F1-score", "Precision", "Recall"]
    scale = [100, 1, 1, 1, 1]
    print("\n" + BAR)
    print("REPEATED-CV INTERVALS (percentile over %d repetitions)" % R)
    print(BAR)
    print("  Metric     | seed-42 | rep mean | 95% CI")
    print("  -----------+---------+----------+------------------")
    rows = []
    for i, nm in enumerate(names):
        v = out[:, i]
        lo, hi = np.percentile(v, [2.5, 97.5])
        s = scale[i]
        fmt = "%.2f" if s == 100 else "%.3f"
        print(("  %-10s | " + fmt + "   | " + fmt + "    | [" + fmt + ", " + fmt + "]")
              % (nm, s * base[i], s * v.mean(), s * lo, s * hi))
        rows.append((nm, s * base[i], s * lo, s * hi))

    print("\n" + BAR)
    print("PASTE-READY")
    print(BAR)
    a = rows[0]
    print("  Section 4.2 / Introduction:")
    print("    95%% CI [%.1f%%, %.1f%%]" % (a[2], a[3]))
    print("\n  Table 2 CI column, in order (Accuracy, AUC, F1, Precision, Recall):")
    for nm, pt, lo, hi in rows:
        if nm == "Accuracy":
            print("    $[%.1f, %.1f]$" % (lo, hi))
        else:
            print("    $[%.3f, %.3f]$" % (lo, hi))
    print("\n  Conservative sensitivity bound already computed by step9")
    print("  (subject-grouped bootstrap): [43.1%, 68.9%]")
    print("\nDone.")


if __name__ == "__main__":
    main()
