# -*- coding: utf-8 -*-
"""
step7_table3.py - regenerates the WHOLE of Table 3 in one run.

WHY: the current table mixes runs. Accuracy for Random Forest and MLP came
from the seed-42 rerun, but their F1 scores are still from the original
run, and XGBoost was never re-run at all. Every cell in a table should come
from the same execution. This script recomputes accuracy, F1, AUC and
best-fold accuracy for all six classifiers under the identical protocol
(10-fold stratified CV, seed 42, fold-specific top-50 selection by Cohen's
d on the training partition, standardisation fitted on training data only,
inverse-frequency class weighting).

XGBoost: if the package is missing the script says so and still prints the
other five rows. If you cannot install it, the cleanest option is to drop
the XGBoost row and say five baselines were compared -- better than
carrying one row from an unreproducible run.

RUN:  python step7_table3.py > table3.txt 2>&1
"""

import os
import sys
from pathlib import Path

import numpy as np

# Path to the extracted feature file. Override without editing this script:
#   Linux/macOS:  export ABIDE_FEATURES=/path/to/features_full3d_64patches.npz
#   Windows:      set ABIDE_FEATURES=C:\path\to\features_full3d_64patches.npz
NYU_PATH = os.environ.get(
    "ABIDE_FEATURES",
    "features/features_full3d_64patches.npz",
)
SEED, K, M = 42, 50, 10
BAR = "=" * 72


def load(path):
    z = np.load(path, allow_pickle=True)
    X = y = None
    for k in z.files:
        a = np.asarray(z[k])
        if a.ndim == 2 and 512 in a.shape:
            X = a if a.shape[1] == 512 else a.T
    for k in z.files:
        a = np.asarray(z[k]).ravel()
        if X is not None and a.size == X.shape[0] and len(np.unique(a)) == 2:
            y = a
    u = np.unique(y)
    y = (y == u.max()).astype(int)
    if (y == 1).sum() != 79 and (y == 0).sum() == 79:
        y = 1 - y
    return X.astype(float), y


def cohens_d(X, y):
    a, b = X[y == 1], X[y == 0]
    sp = np.sqrt((a.var(0, ddof=1) + b.var(0, ddof=1)) / 2.0)
    sp[sp == 0] = 1e-12
    return np.abs(a.mean(0) - b.mean(0)) / sp


def build_models():
    from sklearn.svm import SVC
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.neural_network import MLPClassifier

    models = {
        "SVM Linear (Ours)": lambda: SVC(kernel="linear", C=0.5,
                                         class_weight="balanced"),
        "Logistic Regression": lambda: LogisticRegression(
            C=0.1, max_iter=2000, class_weight="balanced"),
        "Random Forest": lambda: RandomForestClassifier(
            n_estimators=100, max_depth=5, class_weight="balanced",
            random_state=SEED),
        "SVM RBF": lambda: SVC(kernel="rbf", C=1.0, gamma="scale",
                               class_weight="balanced"),
        "MLP": lambda: MLPClassifier(hidden_layer_sizes=(32, 16), alpha=0.01,
                                     early_stopping=True, max_iter=800,
                                     random_state=SEED),
    }
    try:
        from xgboost import XGBClassifier
        models["XGBoost"] = lambda: XGBClassifier(
            n_estimators=100, max_depth=3, learning_rate=0.1,
            eval_metric="logloss", random_state=SEED, verbosity=0)
        print("  xgboost: available")
    except ImportError:
        print("  xgboost: NOT INSTALLED -> row will be omitted.")
        print("           pip install xgboost   (or drop the row from Table 3)")
    return models


def main():
    print(BAR)
    print("STEP 7 - TABLE 3, REGENERATED IN A SINGLE RUN (seed %d)" % SEED)
    print(BAR)
    p = Path(NYU_PATH)
    if not p.exists():
        hits = list(Path.home().rglob("features_full3d_64patches.npz"))
        if not hits:
            print("[FATAL] features not found; edit NYU_PATH."); sys.exit(1)
        p = hits[0]
    X, y = load(p)
    print("  data: %s | ASD %d | HC %d" % (X.shape, (y == 1).sum(), (y == 0).sum()))

    from sklearn.model_selection import StratifiedKFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import f1_score, roc_auc_score

    models = build_models()
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=SEED)
    folds = list(skf.split(X, y))

    print("\n  Method                | Accuracy (%)   | F1    | AUC   | Best fold")
    print("  ----------------------+----------------+-------+-------+----------")
    rows = []
    for name, ctor in models.items():
        acc, f1s, aucs = [], [], []
        for tr, te in folds:
            d = cohens_d(X[tr], y[tr])
            top = np.argsort(-d)[:K]
            sc = StandardScaler().fit(X[tr][:, top])
            Ztr, Zte = sc.transform(X[tr][:, top]), sc.transform(X[te][:, top])
            clf = ctor().fit(Ztr, y[tr])
            pred = clf.predict(Zte)
            acc.append((pred == y[te]).mean())
            f1s.append(f1_score(y[te], pred, zero_division=0))
            try:
                s = (clf.decision_function(Zte)
                     if hasattr(clf, "decision_function")
                     else clf.predict_proba(Zte)[:, 1])
                aucs.append(roc_auc_score(y[te], s))
            except Exception:
                pass
        acc = np.array(acc)
        row = (name, 100 * acc.mean(), 100 * acc.std(ddof=1),
               float(np.mean(f1s)), float(np.mean(aucs)) if aucs else np.nan,
               100 * acc.max())
        rows.append(row)
        print("  %-21s | %5.2f +/- %4.1f  | %.3f | %.3f | %5.2f"
              % (row[0], row[1], row[2], row[3], row[4], row[5]))

    print("\n" + BAR)
    print("PASTE-READY LATEX ROWS (sorted by accuracy)")
    print(BAR)
    for r in sorted(rows, key=lambda r: -r[1]):
        bold = r[0].startswith("SVM Linear")
        fmt = (r"\textbf{%s} & $\mathbf{%.2f \pm %.1f}$ & \textbf{%.3f} & "
               r"\textbf{%.3f} & \textbf{%.2f} \\"
               if bold else r"%s & $%.2f \pm %.1f$ & %.3f & %.3f & %.2f \\")
        name = r[0].replace("(Ours)", "(Ours)")
        print(fmt % (name, r[1], r[2], r[3], r[4], r[5]))
    print("\nReplace the whole body of Table 3 with these rows so that every")
    print("cell comes from this single run.")
    print("\nDone.")


if __name__ == "__main__":
    main()
