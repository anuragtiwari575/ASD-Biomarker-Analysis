# -*- coding: utf-8 -*-
"""
fill_placeholders.py - computes every [S] number in revision_pack.md:
  1. NYU: d, raw min-p, and BH-512 q for ALL 64 patches (fills Table 5's
     q column and the Section 4.6 sentence about 0.05 < q < ... candidates)
  2. KKI / SDSU: d for all 64 patches (fills Table 13 rows 10, 30, 5)
  3. Jaccard verification: consensus vs random baseline, 50 reps
     (verifies the published 0.765 [0.728, 0.798] vs 0.396 [0.378, 0.412])

Run:   python fill_placeholders.py > placeholders.txt 2>&1
Paste placeholders.txt back in full.
"""

import os
import sys
from pathlib import Path

import numpy as np
from scipy import stats

# Path to the extracted feature file. Override without editing this script:
#   Linux/macOS:  export ABIDE_FEATURES=/path/to/features_full3d_64patches.npz
#   Windows:      set ABIDE_FEATURES=C:\path\to\features_full3d_64patches.npz
NYU_PATH = os.environ.get(
    "ABIDE_FEATURES",
    "features/features_full3d_64patches.npz",
)
K, TAU, M, R = 50, 0.5, 10, 50
BAR = "=" * 72


def load_xy(path, asd_expected=None, name="dataset"):
    z = np.load(path, allow_pickle=True)
    X = y = None
    for k in z.files:
        arr = np.asarray(z[k])
        if arr.ndim == 2 and 512 in arr.shape:
            X = arr if arr.shape[1] == 512 else arr.T
        elif arr.ndim == 1 and len(np.unique(arr)) == 2:
            y = arr
    if X is not None and (y is None or y.shape[0] != X.shape[0]):
        for k in z.files:
            arr = np.asarray(z[k]).ravel()
            if arr.size == X.shape[0] and len(np.unique(arr)) == 2:
                y = arr
                break
    u = np.unique(y)
    y = (y == u.max()).astype(int)
    if asd_expected is not None and (y == 1).sum() != asd_expected \
            and (y == 0).sum() == asd_expected:
        y = 1 - y
    print("  [%s] X: %s | ASD: %d | HC: %d"
          % (name, X.shape, (y == 1).sum(), (y == 0).sum()))
    return X.astype(float), y


def cohens_d_vec(X, y):
    a, b = X[y == 1], X[y == 0]
    sp = np.sqrt((a.var(0, ddof=1) + b.var(0, ddof=1)) / 2.0)
    sp[sp == 0] = 1e-12
    return np.abs(a.mean(0) - b.mean(0)) / sp


def bh_adjust(p):
    p = np.asarray(p, float)
    n = p.size
    order = np.argsort(p)
    adj = p[order] * n / (np.arange(n) + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.clip(adj, 0, 1)
    return out


def hemi(p):
    return "R" if p % 4 >= 2 else "L"


def patch_table(X, y):
    d = cohens_d_vec(X, y)
    _, pv = stats.ttest_ind(X[y == 1], X[y == 0], equal_var=False)
    pv = np.where(np.isnan(np.asarray(pv, float)), 1.0, pv)
    q = bh_adjust(pv)
    rows = []
    for p in range(64):
        sl = slice(8 * p, 8 * p + 8)
        rows.append((p, hemi(p), float(np.nanmax(d[sl])),
                     float(np.min(pv[sl])), float(np.min(q[sl]))))
    return rows


def fold_sets(X, y, seed):
    from sklearn.model_selection import StratifiedKFold
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=seed)
    sets = []
    for tr, _ in skf.split(X, y):
        d = cohens_d_vec(X[tr], y[tr])
        top = np.argsort(-d)[:K]
        sets.append(set(np.unique(top // 8).tolist()))
    return sets


def mean_jaccard(sets):
    vals = []
    for i in range(len(sets)):
        for j in range(i + 1, len(sets)):
            inter = len(sets[i] & sets[j])
            union = len(sets[i] | sets[j])
            vals.append(inter / union if union else 0.0)
    return float(np.mean(vals))


def main():
    print(BAR)
    print("FILL PLACEHOLDERS")
    print(BAR)
    nyu_path = Path(NYU_PATH)
    if not nyu_path.exists():
        hits = list(Path.home().rglob("features_full3d_64patches.npz"))
        if not hits:
            print("[FATAL] NYU features not found; edit NYU_PATH.")
            sys.exit(1)
        nyu_path = hits[0]
    Xn, yn = load_xy(nyu_path, 79, "NYU")

    # ------------------------------------------------ 1. NYU all-64 table
    print("\n" + BAR)
    print("1. NYU - ALL 64 PATCHES (d, raw min-p, BH-512 q)")
    print(BAR)
    print("  patch | hemi | max d | min p    | q (BH-512) | q<0.05")
    print("  ------+------+-------+----------+------------+-------")
    nyu_rows = patch_table(Xn, yn)
    for p, h, d, praw, q in nyu_rows:
        print("   %4d |  %s   | %.3f | %.2e | %.4f     | %s"
              % (p, h, d, praw, q, "YES" if q < 0.05 else ""))
    consensus20 = [5, 6, 9, 10, 14, 22, 23, 26, 27, 30, 38, 39, 41, 42, 43,
                   46, 49, 57, 58, 62]
    qs = {p: q for p, _, _, _, q in nyu_rows}
    stable18 = [p for p in consensus20 if p not in (41, 49)]
    q_stable = [qs[p] for p in stable18 if qs[p] >= 0.05]
    print("\n  For Section 4.6 sentence: %d fold-stable patches with q>=0.05,"
          % len(q_stable))
    print("  q range %.3f - %.3f" % (min(q_stable), max(q_stable)))

    # ------------------------------------------------ 2. externals
    print("\n" + BAR)
    print("2. KKI / SDSU - d for all 64 (Table 13 needs patches 5, 10, 30)")
    print(BAR)
    root = nyu_path.resolve().parents[1] if len(nyu_path.resolve().parents) > 1 \
        else nyu_path.parent
    expected = {"kki": 56, "sdsu": 33}
    for f in sorted(root.rglob("*.npz")):
        low = f.name.lower()
        for tag in ("kki", "sdsu"):
            if tag in low:
                try:
                    Xc, yc = load_xy(f, expected[tag], tag.upper())
                except Exception as e:
                    print("  [%s] error: %s" % (tag.upper(), e))
                    continue
                rows = patch_table(Xc, yc)
                dmap = {p: d for p, _, d, _, _ in rows}
                print("  %s highlight -> patch 5: d=%.3f | patch 10: d=%.3f"
                      " | patch 30: d=%.3f"
                      % (tag.upper(), dmap[5], dmap[10], dmap[30]))
                print("  %s full d list (patch: d): %s"
                      % (tag.upper(),
                         {p: round(d, 3) for p, _, d, _, _ in rows}))
                expected.pop(tag, None)
        if not expected:
            break

    # ------------------------------------------------ 3. Jaccard verify
    print("\n" + BAR)
    print("3. JACCARD VERIFICATION (published: 0.765 [0.728, 0.798] vs")
    print("   random baseline 0.396 [0.378, 0.412])")
    print(BAR)
    rng_master = np.random.RandomState(2026)
    cons_vals, rand_vals = [], []
    for rep in range(R):
        cons_vals.append(mean_jaccard(fold_sets(Xn, yn, seed=rep)))
        rng = np.random.RandomState(rng_master.randint(0, 10**6))
        rsets = []
        for _ in range(M):
            feats = rng.choice(512, size=K, replace=False)
            rsets.append(set(np.unique(feats // 8).tolist()))
        rand_vals.append(mean_jaccard(rsets))
    cons_vals = np.array(cons_vals)
    rand_vals = np.array(rand_vals)

    def ci(v):
        return np.percentile(v, 2.5), np.percentile(v, 97.5)

    c_lo, c_hi = ci(cons_vals)
    r_lo, r_hi = ci(rand_vals)
    print("  Consensus: mean %.3f  95%% CI [%.3f, %.3f]  SD %.3f"
          % (cons_vals.mean(), c_lo, c_hi, cons_vals.std(ddof=1)))
    print("  Random:    mean %.3f  95%% CI [%.3f, %.3f]  SD %.3f"
          % (rand_vals.mean(), r_lo, r_hi, rand_vals.std(ddof=1)))
    print("  Delta: %+.3f (%.1f%% relative)"
          % (cons_vals.mean() - rand_vals.mean(),
             100 * (cons_vals.mean() - rand_vals.mean()) / rand_vals.mean()))
    print("  Matches published 0.765 / 0.396? "
          "consensus %s | random %s"
          % ("YES" if abs(cons_vals.mean() - 0.765) < 0.02 else "NO",
             "YES" if abs(rand_vals.mean() - 0.396) < 0.02 else "NO"))
    print("\nDone.")


if __name__ == "__main__":
    main()
