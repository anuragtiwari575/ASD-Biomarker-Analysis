# -*- coding: utf-8 -*-
"""
step8_ksweep.py - reruns the K-sensitivity analysis (Table 9) with the same
pinned seeds as the main analysis.

WHY: Table 9 currently reports a mean Jaccard of 0.765 (95% CI [0.728,
0.798]) for K = 50, while Section 4.5 reports 0.769 (95% CI [0.728, 0.809])
for the identical configuration. Both describe the same quantity - K = 50,
50 repetitions, 10-fold stratified splits, mean of the 45 pairwise
patch-level Jaccard comparisons - so they must agree. The discrepancy is
because Table 9 came from the original unpinned run. This script regenerates
every row of the table under repetition seeds 0-49, so the K = 50 row
reproduces the main-text value exactly.

RUN:  python step8_ksweep.py > ksweep.txt 2>&1
"""

import os
import sys
from pathlib import Path

import numpy as np

# Path to the extracted feature file. Override without editing this script:
#   Linux/macOS:  export ABIDE_FEATURES=/path/to/features_full3d_64patches.npz
#   Windows:      set ABIDE_FEATURES=C:\path\to\features_full3d_64patches.npz
NYU_PATH = os.environ.get(
    "ABIDE_FEATURES",
    "features/features_full3d_64patches.npz",
)
K_VALUES = [25, 50, 75, 100, 150]
TAU_VALUES = [0.4, 0.5, 0.6, 0.7]
M, REPS = 10, 50
BAR = "=" * 72


def load(path):
    z = np.load(path, allow_pickle=True)
    X = y = None
    for k in z.files:
        a = np.asarray(z[k])
        if a.ndim == 2 and 512 in a.shape:
            X = a if a.shape[1] == 512 else a.T
    for k in z.files:
        a = np.asarray(z[k]).ravel()
        if X is not None and a.size == X.shape[0] and len(np.unique(a)) == 2:
            y = a
    u = np.unique(y)
    y = (y == u.max()).astype(int)
    if (y == 1).sum() != 79 and (y == 0).sum() == 79:
        y = 1 - y
    return X.astype(float), y


def cohens_d(X, y):
    a, b = X[y == 1], X[y == 0]
    sp = np.sqrt((a.var(0, ddof=1) + b.var(0, ddof=1)) / 2.0)
    sp[sp == 0] = 1e-12
    return np.abs(a.mean(0) - b.mean(0)) / sp


def fold_patch_sets(X, y, seed, K):
    from sklearn.model_selection import StratifiedKFold
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=seed)
    out = []
    for tr, _ in skf.split(X, y):
        d = cohens_d(X[tr], y[tr])
        out.append(set(np.unique(np.argsort(-d)[:K] // 8).tolist()))
    return out


def mean_jaccard(sets):
    v = []
    for i in range(len(sets)):
        for j in range(i + 1, len(sets)):
            u = len(sets[i] | sets[j])
            v.append(len(sets[i] & sets[j]) / u if u else 0.0)
    return float(np.mean(v))


def main():
    print(BAR)
    print("STEP 8 - K- AND TAU-SENSITIVITY, PINNED SEEDS (reps 0-49)")
    print(BAR)
    p = Path(NYU_PATH)
    if not p.exists():
        hits = list(Path.home().rglob("features_full3d_64patches.npz"))
        if not hits:
            print("[FATAL] features not found; edit NYU_PATH."); sys.exit(1)
        p = hits[0]
    X, y = load(p)
    print("  data: %s | ASD %d | HC %d\n" % (X.shape, (y == 1).sum(), (y == 0).sum()))

    # cache fold sets per (K, rep) so the tau sweep is free
    cache = {}
    print("  K   | Mean Jaccard | 95% CI            | SD")
    print("  ----+--------------+-------------------+------")
    for K in K_VALUES:
        vals = []
        for rep in range(REPS):
            s = fold_patch_sets(X, y, rep, K)
            cache[(K, rep)] = s
            vals.append(mean_jaccard(s))
        vals = np.array(vals)
        lo, hi = np.percentile(vals, [2.5, 97.5])
        flag = "   <- must match Section 4.5" if K == 50 else ""
        print("  %3d | %.3f        | [%.3f, %.3f]    | %.3f%s"
              % (K, vals.mean(), lo, hi, vals.std(ddof=1), flag))

    print("\n  tau | Mean size | SD   | 95% CI         | In all 50 | Union")
    print("  ----+-----------+------+----------------+-----------+------")
    for tau in TAU_VALUES:
        sizes, inter, union = [], None, set()
        for rep in range(REPS):
            sets = cache[(50, rep)]
            freq = {}
            for s in sets:
                for pch in s:
                    freq[pch] = freq.get(pch, 0) + 1
            cons = {pch for pch, c in freq.items() if c / M >= tau}
            sizes.append(len(cons))
            inter = cons if inter is None else (inter & cons)
            union |= cons
        sizes = np.array(sizes)
        lo, hi = np.percentile(sizes, [2.5, 97.5])
        print("  %.1f | %9.2f | %.2f | [%.1f, %.1f]     | %9d | %5d"
              % (tau, sizes.mean(), sizes.std(ddof=1), lo, hi, len(inter), len(union)))
        if abs(tau - 0.5) < 1e-9:
            print("        consensus present in all 50 reps at tau=0.5: %s"
                  % sorted(inter))

    print("\nUse the K=50 row to replace the 0.765 [0.728, 0.798] entry in")
    print("Table 9 so it agrees with Section 4.5.")
    print("\nDone.")


if __name__ == "__main__":
    main()
