# -*- coding: utf-8 -*-
"""
step5_remaining_stats.py - fills every remaining numeric PENDING:

  A. Table 8 / Section 4.9 : IQ-adjusted analysis of patches {10, 46}
                             + IQ-adjusted laterality + adjusted SVM accuracy
  B. Table 15              : full classifier grid for NYU / KKI / SDSU with
                             accuracy, balanced accuracy, AUC, sensitivity,
                             specificity (seed-42 protocol)
  C. Section 4.9 addendum  : sex-adjusted sensitivity analysis (recommended
                             now that the sex p-value is ~0.069, not 0.71)

PHENOTYPE FILE: needed only for parts A and C. The script searches for an
ABIDE phenotype CSV automatically. If your NPZ has no subject IDs, parts A
and C are skipped with a clear message and part B still runs.

RUN:
    python step5_remaining_stats.py > remaining.txt 2>&1
"""

import os
import sys
from pathlib import Path

import numpy as np
from scipy import stats

# Path to the extracted feature file. Override without editing this script:
#   Linux/macOS:  export ABIDE_FEATURES=/path/to/features_full3d_64patches.npz
#   Windows:      set ABIDE_FEATURES=C:\path\to\features_full3d_64patches.npz
NYU_PATH = os.environ.get(
    "ABIDE_FEATURES",
    "features/features_full3d_64patches.npz",
)
SEED, K, M = 42, 50, 10
PRINCIPAL = [10, 46]
BAR = "=" * 72


# --------------------------------------------------------------- loading
def load_npz(path, asd_expected=None, name="dataset"):
    z = np.load(path, allow_pickle=True)
    X = y = ids = None
    for k in z.files:
        arr = np.asarray(z[k])
        if arr.ndim == 2 and 512 in arr.shape:
            X = arr if arr.shape[1] == 512 else arr.T
    for k in z.files:
        arr = np.asarray(z[k]).ravel()
        if X is None or arr.size != X.shape[0]:
            continue
        if len(np.unique(arr)) == 2 and y is None:
            y = arr
        elif arr.dtype.kind in "iuOSU" and len(np.unique(arr)) > 2 and ids is None:
            ids = arr
    u = np.unique(y)
    y = (y == u.max()).astype(int)
    if asd_expected is not None and (y == 1).sum() != asd_expected \
            and (y == 0).sum() == asd_expected:
        y = 1 - y
    print("  [%s] X %s | ASD %d | HC %d | subject IDs: %s"
          % (name, X.shape, (y == 1).sum(), (y == 0).sum(),
             "found" if ids is not None else "NOT FOUND"))
    return X.astype(float), y, ids


def find_phenotype():
    pats = ["*henotypic*.csv", "*phenotype*.csv", "*Phenotypic*.csv"]
    roots = [Path(NYU_PATH).resolve().parent.parent, Path.home()]
    for root in roots:
        if not root.exists():
            continue
        for pat in pats:
            for f in root.rglob(pat):
                return f
    return None


def match_phenotype(ids, pheno_path, cols):
    import csv
    key = {}
    with open(pheno_path, newline="", encoding="utf-8", errors="ignore") as fh:
        for row in csv.DictReader(fh):
            sid = None
            for c in ("SUB_ID", "subject", "SubID", "sub_id"):
                if c in row and row[c].strip():
                    sid = "".join(ch for ch in row[c] if ch.isdigit())
                    break
            if sid:
                key[sid.lstrip("0")] = row
    out = {c: np.full(len(ids), np.nan) for c in cols}
    hit = 0
    for n, raw in enumerate(ids):
        sid = "".join(ch for ch in str(raw) if ch.isdigit()).lstrip("0")
        row = key.get(sid)
        if row is None:
            continue
        hit += 1
        for c in cols:
            for cand in (c, c.upper(), c.replace("_", "")):
                if cand in row:
                    try:
                        v = float(row[cand])
                        out[c][n] = np.nan if v in (-9999, 999, -999) else v
                    except (TypeError, ValueError):
                        pass
                    break
    print("  matched %d/%d subjects to phenotype" % (hit, len(ids)))
    return out


# --------------------------------------------------------------- stats
def cohens_d_vec(X, y):
    a, b = X[y == 1], X[y == 0]
    sp = np.sqrt((a.var(0, ddof=1) + b.var(0, ddof=1)) / 2.0)
    sp[sp == 0] = 1e-12
    return np.abs(a.mean(0) - b.mean(0)) / sp


def bh(p):
    p = np.asarray(p, float)
    n = p.size
    o = np.argsort(p)
    adj = p[o] * n / (np.arange(n) + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    out = np.empty(n)
    out[o] = np.clip(adj, 0, 1)
    return out


def patch_stats(X, y):
    d = cohens_d_vec(X, y)
    _, pv = stats.ttest_ind(X[y == 1], X[y == 0], equal_var=False)
    pv = np.where(np.isnan(np.asarray(pv, float)), 1.0, pv)
    q = bh(pv)
    return ({p: float(np.nanmax(d[8 * p:8 * p + 8])) for p in range(64)},
            {p: float(np.min(q[8 * p:8 * p + 8])) for p in range(64)})


def residualize(X, cov):
    ok = ~np.isnan(cov)
    Xr = X.copy()
    A = np.column_stack([np.ones(ok.sum()), cov[ok]])
    beta, *_ = np.linalg.lstsq(A, X[ok], rcond=None)
    Xr[ok] = X[ok] - A @ beta
    return Xr, ok


def laterality(dmap):
    L, R = [], []
    for i in range(4):
        for j in range(4):
            base = 16 * i + 4 * j
            L.append(max(dmap[base + 0], dmap[base + 1]))
            R.append(max(dmap[base + 2], dmap[base + 3]))
    L, R = np.array(L), np.array(R)
    W, p = stats.wilcoxon(R, L, alternative="greater")
    return L.mean(), R.mean(), R.mean() / L.mean(), int((R > L).sum()), W, p


def classifier_grid(X, y, name):
    from sklearn.model_selection import StratifiedKFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.svm import SVC
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.neural_network import MLPClassifier
    from sklearn.metrics import roc_auc_score

    models = {
        "SVM Linear": lambda: SVC(kernel="linear", C=0.5, class_weight="balanced"),
        "Logistic Regression": lambda: LogisticRegression(
            C=0.1, max_iter=2000, class_weight="balanced"),
        "SVM RBF": lambda: SVC(kernel="rbf", C=1.0, gamma="scale",
                               class_weight="balanced"),
        "Random Forest": lambda: RandomForestClassifier(
            n_estimators=100, max_depth=5, class_weight="balanced",
            random_state=SEED),
        "MLP": lambda: MLPClassifier(hidden_layer_sizes=(32, 16), alpha=0.01,
                                     early_stopping=True, max_iter=800,
                                     random_state=SEED),
    }
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=SEED)
    print("\n  --- %s ---" % name)
    print("  classifier            |  acc  | bal.acc |  AUC  | sens  | spec")
    print("  ----------------------+-------+---------+-------+-------+------")
    for mname, ctor in models.items():
        accs, bals, aucs, sens, spec = [], [], [], [], []
        for tr, te in skf.split(X, y):
            d = cohens_d_vec(X[tr], y[tr])
            top = np.argsort(-d)[:K]
            sc = StandardScaler().fit(X[tr][:, top])
            Ztr, Zte = sc.transform(X[tr][:, top]), sc.transform(X[te][:, top])
            clf = ctor().fit(Ztr, y[tr])
            pred = clf.predict(Zte)
            yt = y[te]
            tp = ((pred == 1) & (yt == 1)).sum(); fn = ((pred == 0) & (yt == 1)).sum()
            tn = ((pred == 0) & (yt == 0)).sum(); fp = ((pred == 1) & (yt == 0)).sum()
            se = tp / (tp + fn) if tp + fn else np.nan
            sp = tn / (tn + fp) if tn + fp else np.nan
            accs.append((pred == yt).mean()); sens.append(se); spec.append(sp)
            bals.append(np.nanmean([se, sp]))
            try:
                score = (clf.decision_function(Zte)
                         if hasattr(clf, "decision_function")
                         else clf.predict_proba(Zte)[:, 1])
                aucs.append(roc_auc_score(yt, score))
            except Exception:
                pass
        print("  %-21s | %5.1f | %6.1f  | %.3f | %5.1f | %5.1f"
              % (mname, 100 * np.mean(accs), 100 * np.nanmean(bals),
                 np.mean(aucs) if aucs else float("nan"),
                 100 * np.nanmean(sens), 100 * np.nanmean(spec)))


def adjusted_svm(X, y, cov, label):
    """Fold-wise residualisation: coefficients fitted on training data only."""
    from sklearn.model_selection import StratifiedKFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.svm import SVC
    ok = ~np.isnan(cov)
    X, y, cov = X[ok], y[ok], cov[ok]
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=SEED)
    accs = []
    for tr, te in skf.split(X, y):
        A = np.column_stack([np.ones(len(tr)), cov[tr]])
        beta, *_ = np.linalg.lstsq(A, X[tr], rcond=None)
        Xtr = X[tr] - A @ beta
        Ate = np.column_stack([np.ones(len(te)), cov[te]])
        Xte = X[te] - Ate @ beta
        d = cohens_d_vec(Xtr, y[tr])
        top = np.argsort(-d)[:K]
        sc = StandardScaler().fit(Xtr[:, top])
        clf = SVC(kernel="linear", C=0.5, class_weight="balanced").fit(
            sc.transform(Xtr[:, top]), y[tr])
        accs.append((clf.predict(sc.transform(Xte[:, top])) == y[te]).mean())
    accs = np.array(accs)
    print("  %s-adjusted SVM: %.2f%% +/- %.1f%% | best fold %.2f%% (n=%d)"
          % (label, 100 * accs.mean(), 100 * accs.std(ddof=1),
             100 * accs.max(), len(y)))


# --------------------------------------------------------------- main
def main():
    print(BAR)
    print("STEP 5 - REMAINING MANUSCRIPT NUMBERS")
    print(BAR)
    nyu = Path(NYU_PATH)
    if not nyu.exists():
        hits = list(Path.home().rglob("features_full3d_64patches.npz"))
        if not hits:
            print("[FATAL] NYU features not found; edit NYU_PATH.")
            sys.exit(1)
        nyu = hits[0]
    Xn, yn, ids = load_npz(nyu, 79, "NYU")

    # ---------------------------------------------------- A + C
    print("\n" + BAR)
    print("A/C. IQ- AND SEX-ADJUSTED ANALYSES (Table 8, Section 4.9)")
    print(BAR)
    if ids is None:
        print("  [SKIPPED] No subject IDs in the NPZ, so phenotype cannot be")
        print("  matched. Re-export the features with the ID array, or run")
        print("  your original IQ script on patches [10, 46].")
    else:
        ph = find_phenotype()
        if ph is None:
            print("  [SKIPPED] No phenotype CSV found. Download")
            print("  Phenotypic_V1_0b_preprocessed1.csv from ABIDE and place")
            print("  it next to the features file, then re-run.")
        else:
            print("  phenotype: %s" % ph)
            cov = match_phenotype(ids, ph, ["FIQ", "SEX"])
            d_un, q_un = patch_stats(Xn, yn)
            for cname, key in (("IQ", "FIQ"), ("SEX", "SEX")):
                c = cov[key]
                if np.all(np.isnan(c)):
                    print("\n  [%s] column not found in phenotype - skipped" % cname)
                    continue
                print("\n  --- %s-adjusted ---" % cname)
                Xr, ok = residualize(Xn, c)
                d_ad, q_ad = patch_stats(Xr[ok], yn[ok])
                print("  patch | unadj d | adj d | unadj q | adj q  | still q<0.05")
                print("  ------+---------+-------+---------+--------+-------------")
                for p in PRINCIPAL:
                    print("   %4d |  %.3f  | %.3f | %.4f  | %.4f | %s"
                          % (p, d_un[p], d_ad[p], q_un[p], q_ad[p],
                             "YES" if q_ad[p] < 0.05 else "no"))
                mL, mR, ratio, npair, W, pw = laterality(d_ad)
                print("  laterality after adjustment: L %.3f | R %.3f | %.2fx |"
                      " %d/16 | W=%d | p=%.4f"
                      % (mL, mR, ratio, npair, W, pw))
                adjusted_svm(Xn, yn, c, cname)

    # ---------------------------------------------------- B
    print("\n" + BAR)
    print("B. TABLE 15 - FULL CLASSIFIER GRID (seed 42)")
    print(BAR)
    classifier_grid(Xn, yn, "NYU (discovery)")
    root = nyu.resolve().parents[1] if len(nyu.resolve().parents) > 1 else nyu.parent
    expected = {"kki": 56, "sdsu": 33}
    for f in sorted(root.rglob("*.npz")):
        low = f.name.lower()
        for tag in list(expected):
            if tag in low:
                try:
                    Xc, yc, _ = load_npz(f, expected[tag], tag.upper())
                    classifier_grid(Xc, yc, "%s (replication)" % tag.upper())
                except Exception as e:
                    print("  [%s] error: %s" % (tag.upper(), e))
                expected.pop(tag, None)
    if expected:
        print("\n  [WARN] not found: %s" % ", ".join(expected))
    print("\nDone.")


if __name__ == "__main__":
    main()
