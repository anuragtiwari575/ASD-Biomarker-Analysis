# -*- coding: utf-8 -*-
"""
step6_figures.py - regenerate Figures 5-9 with the corrected results.

Outputs (600 dpi PNG, ready to drop into latex/figures/):
    fig5.png  consensus discovery + stability   (20 patches, Jaccard 0.769)
    fig6.png  effect-size landscape, 4 axial slices, corrected overlays
    fig7.png  2D projections (sagittal / coronal / axial)
    fig8.png  laterality panel (W = 123, p = 0.0013)
    fig9.png  consensus map: principal (10, 46) vs stability-based

Overlay convention used throughout:
    solid red   = FDR-significant principal biomarkers (10, 46)
    dashed blue = the other 18 consensus patches
    grey        = non-consensus patches

RUN:  python step6_figures.py > figures.txt 2>&1
Then copy fig5.png ... fig9.png into your LaTeX figures/ folder
(replacing fig5.jpeg -- also change the extension in body.tex if you do).
"""

import os
import sys
from pathlib import Path

import numpy as np
from scipy import stats

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

# Path to the extracted feature file. Override without editing this script:
#   Linux/macOS:  export ABIDE_FEATURES=/path/to/features_full3d_64patches.npz
#   Windows:      set ABIDE_FEATURES=C:\path\to\features_full3d_64patches.npz
NYU_PATH = os.environ.get(
    "ABIDE_FEATURES",
    "features/features_full3d_64patches.npz",
)
SEED, K, M, REPS = 42, 50, 10, 50
CONSENSUS = [5, 6, 9, 10, 14, 22, 23, 26, 27, 30, 38, 39, 41, 42, 43, 46, 49, 57, 58, 62]
PRINCIPAL = [10, 46]
UNSTABLE = {41: "8/50", 49: "38/50"}
DPI = 600


def load(path):
    z = np.load(path, allow_pickle=True)
    X = y = None
    for k in z.files:
        a = np.asarray(z[k])
        if a.ndim == 2 and 512 in a.shape:
            X = a if a.shape[1] == 512 else a.T
    for k in z.files:
        a = np.asarray(z[k]).ravel()
        if X is not None and a.size == X.shape[0] and len(np.unique(a)) == 2:
            y = a
    u = np.unique(y)
    y = (y == u.max()).astype(int)
    if (y == 1).sum() != 79 and (y == 0).sum() == 79:
        y = 1 - y
    return X.astype(float), y


def cohens_d(X, y):
    a, b = X[y == 1], X[y == 0]
    sp = np.sqrt((a.var(0, ddof=1) + b.var(0, ddof=1)) / 2.0)
    sp[sp == 0] = 1e-12
    return np.abs(a.mean(0) - b.mean(0)) / sp


def patch_d(X, y):
    d = cohens_d(X, y)
    return np.array([np.nanmax(d[8 * p:8 * p + 8]) for p in range(64)])


def sel_freq(X, y):
    from sklearn.model_selection import StratifiedKFold
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=SEED)
    cnt = np.zeros(64)
    for tr, _ in skf.split(X, y):
        d = cohens_d(X[tr], y[tr])
        for p in np.unique(np.argsort(-d)[:K] // 8):
            cnt[p] += 1
    return cnt / M


def ijk(p):
    return p // 16, (p % 16) // 4, p % 4


def style(p):
    if p in PRINCIPAL:
        return dict(edgecolor="#c1121f", linewidth=2.2, linestyle="-")
    if p in CONSENSUS:
        return dict(edgecolor="#1d4e89", linewidth=1.6, linestyle="--")
    return dict(edgecolor="none", linewidth=0)


# ------------------------------------------------------------- figures
def fig5(dvals, freq, out):
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
    order = np.argsort(-dvals)
    cols = ["#c1121f" if p in PRINCIPAL else "#1d4e89" if p in CONSENSUS
            else "#c9ccd1" for p in order]
    ax[0].bar(range(64), dvals[order], color=cols)
    ax[0].set_xlabel("Patch (ranked by effect size)")
    ax[0].set_ylabel("Cohen's $d$")
    ax[0].set_title("(a) Patch-wise discriminability")
    ax[0].axhline(0.2, ls=":", c="grey", lw=.8)
    ax[0].axhline(0.5, ls=":", c="grey", lw=.8)

    o2 = np.argsort(-freq)
    cols2 = ["#c1121f" if p in PRINCIPAL else "#1d4e89" if freq[p] >= .5
             else "#c9ccd1" for p in o2]
    ax[1].bar(range(64), freq[o2], color=cols2)
    ax[1].axhline(0.5, color="k", ls="--", lw=1)
    ax[1].text(40, .53, r"$\tau = 0.5$", fontsize=9)
    ax[1].set_xlabel("Patch (ranked by selection frequency)")
    ax[1].set_ylabel("Selection frequency $f_p$")
    ax[1].set_title("(b) Cross-fold selection: 20 consensus patches")

    ax[2].bar([0, 1], [0.769, 0.396], color=["#1d4e89", "#c9ccd1"],
              yerr=[[0.041, 0.022], [0.040, 0.025]], capsize=6, width=.55)
    ax[2].set_xticks([0, 1])
    ax[2].set_xticklabels(["Consensus\nprocedure", "Random\nbaseline"])
    ax[2].set_ylabel("Mean pairwise Jaccard index")
    ax[2].set_ylim(0, 1)
    ax[2].set_title("(c) Stability vs matched baseline")
    for x, v in ((0, 0.769), (1, 0.396)):
        ax[2].text(x, v + .06, "%.3f" % v, ha="center", fontweight="bold")
    ax[2].text(.5, .13, "+0.373 (94.0%)", ha="center", fontsize=9,
               transform=ax[2].transAxes)
    fig.tight_layout(); fig.savefig(out, dpi=DPI); plt.close(fig)


def fig6(dvals, out):
    fig, axes = plt.subplots(1, 4, figsize=(16, 4.3))
    vmax = dvals.max()
    for i, ax in enumerate(axes):
        grid = np.array([[dvals[16 * i + 4 * j + k] for k in range(4)]
                         for j in range(4)])
        im = ax.imshow(grid, cmap="RdYlBu_r", vmin=0, vmax=vmax)
        for j in range(4):
            for k in range(4):
                p = 16 * i + 4 * j + k
                st = style(p)
                if st["linewidth"]:
                    ax.add_patch(Rectangle((k - .5, j - .5), 1, 1,
                                           fill=False, **st))
                ax.text(k, j, str(p), ha="center", va="center", fontsize=7,
                        color="k")
        ax.axvline(1.5, color="#333", lw=2)
        ax.set_title("$i = %d$" % i)
        ax.set_xticks(range(4)); ax.set_xticklabels(["L", "L", "R", "R"])
        ax.set_yticks(range(4)); ax.set_ylabel("$j$" if i == 0 else "")
    fig.colorbar(im, ax=axes, shrink=.8, label="Cohen's $d$")
    fig.suptitle("Effect-size landscape (red = FDR-significant 10, 46; "
                 "dashed blue = consensus)", y=1.02)
    fig.savefig(out, dpi=DPI, bbox_inches="tight"); plt.close(fig)


def fig7(dvals, out):
    cube = np.zeros((4, 4, 4))
    for p in range(64):
        i, j, k = ijk(p)
        cube[i, j, k] = dvals[p]
    fig, ax = plt.subplots(1, 3, figsize=(13, 4))
    views = [("Sagittal (mean over $k$)", cube.mean(2), "$j$", "$i$"),
             ("Coronal (mean over $j$)", cube.mean(1), "$k$ (L$\\rightarrow$R)", "$i$"),
             ("Axial (mean over $i$)", cube.mean(0), "$k$ (L$\\rightarrow$R)", "$j$")]
    for a, (t, m, xl, yl) in zip(ax, views):
        im = a.imshow(m, cmap="RdYlBu_r")
        a.set_title(t); a.set_xlabel(xl); a.set_ylabel(yl)
        if "k" in xl:
            a.axvline(1.5, color="#8b0000", lw=3)
        fig.colorbar(im, ax=a, shrink=.85)
    fig.tight_layout(); fig.savefig(out, dpi=DPI); plt.close(fig)


def fig8(dvals, out):
    L, R = [], []
    for i in range(4):
        for j in range(4):
            b = 16 * i + 4 * j
            L.append(max(dvals[b], dvals[b + 1]))
            R.append(max(dvals[b + 2], dvals[b + 3]))
    L, R = np.array(L), np.array(R)
    W, p = stats.wilcoxon(R, L, alternative="greater")
    li = (R - L) / (R + L + 1e-8)

    fig, ax = plt.subplots(2, 2, figsize=(11, 8.5))
    for n in range(16):
        ax[0, 0].plot([0, 1], [L[n], R[n]], "-o", ms=4,
                      color="#c1121f" if R[n] > L[n] else "#4a6fa5", alpha=.75)
    ax[0, 0].set_xticks([0, 1]); ax[0, 0].set_xticklabels(["Left", "Right"])
    ax[0, 0].set_ylabel("Max Cohen's $d$ in pair")
    ax[0, 0].set_title("(a) Paired L-R comparison: %d/16 right-dominant\n"
                       "$W = %d$, one-sided $p = %.4f$" % ((R > L).sum(), W, p))

    ax[0, 1].hist(li, bins=10, color="#1d4e89", edgecolor="w")
    ax[0, 1].axvline(0, color="k", ls="--")
    ax[0, 1].set_xlabel("Laterality index"); ax[0, 1].set_ylabel("Count")
    ax[0, 1].set_title("(b) Laterality index distribution")

    vmax = max(L.max(), R.max())
    for a, vals, t in ((ax[1, 0], L, "(c) Left hemisphere"),
                       (ax[1, 0], R, None)):
        break
    im = ax[1, 0].imshow(np.vstack([L.reshape(4, 4).ravel(),
                                    R.reshape(4, 4).ravel()]).reshape(2, 16),
                         cmap="RdYlBu_r", vmin=0, vmax=vmax, aspect="auto")
    ax[1, 0].set_yticks([0, 1]); ax[1, 0].set_yticklabels(["Left", "Right"])
    ax[1, 0].set_xlabel("Patch pair index")
    ax[1, 0].set_title("(c) Hemisphere effect-size maps")
    fig.colorbar(im, ax=ax[1, 0], shrink=.8)

    bp = ax[1, 1].boxplot([L, R], labels=["Left", "Right"], patch_artist=True)
    for patch, c in zip(bp["boxes"], ["#4a6fa5", "#c1121f"]):
        patch.set_facecolor(c); patch.set_alpha(.65)
    ax[1, 1].set_ylabel("Max Cohen's $d$")
    ax[1, 1].set_title("(d) Effect size by hemisphere\nmean %.3f vs %.3f (%.2f$\\times$)"
                       % (L.mean(), R.mean(), R.mean() / L.mean()))
    fig.tight_layout(); fig.savefig(out, dpi=DPI); plt.close(fig)
    print("  fig8 recomputed: W=%d, p=%.4f, %d/16, ratio %.2f"
          % (W, p, (R > L).sum(), R.mean() / L.mean()))


def fig9(dvals, out):
    fig, axes = plt.subplots(1, 4, figsize=(16, 4.3))
    for i, ax in enumerate(axes):
        ax.set_xlim(-.5, 3.5); ax.set_ylim(3.5, -.5)
        for j in range(4):
            for k in range(4):
                p = 16 * i + 4 * j + k
                if p in PRINCIPAL:
                    fc, alpha = "#c1121f", .95
                elif p in CONSENSUS:
                    fc, alpha = "#8d99ae", .75
                else:
                    fc, alpha = "#f1f1f1", .5
                ax.add_patch(Rectangle((k - .5, j - .5), 1, 1, facecolor=fc,
                                       edgecolor="w", alpha=alpha))
                lbl = str(p)
                if p in UNSTABLE:
                    lbl += "*"
                ax.text(k, j, lbl, ha="center", va="center", fontsize=8,
                        color="w" if p in PRINCIPAL or p in CONSENSUS else "#999")
        ax.axvline(1.5, color="#333", lw=2)
        ax.set_title("$i = %d$" % i)
        ax.set_xticks(range(4)); ax.set_xticklabels(["L", "L", "R", "R"])
        ax.set_yticks(range(4))
    fig.suptitle("Consensus map: red = principal FDR-significant (10, 46); "
                 "grey = stability-based; * = not in all 50 repetitions", y=1.03)
    fig.savefig(out, dpi=DPI, bbox_inches="tight"); plt.close(fig)


def main():
    p = Path(NYU_PATH)
    if not p.exists():
        hits = list(Path.home().rglob("features_full3d_64patches.npz"))
        if not hits:
            print("[FATAL] features not found; edit NYU_PATH."); sys.exit(1)
        p = hits[0]
    X, y = load(p)
    print("loaded:", X.shape, "| ASD", (y == 1).sum(), "| HC", (y == 0).sum())
    d = patch_d(X, y)
    f = sel_freq(X, y)
    print("consensus at tau=0.5:", sorted(np.where(f >= .5)[0].tolist()))
    out = Path(".")
    fig5(d, f, out / "fig5.png"); print("  wrote fig5.png")
    fig6(d, out / "fig6.png"); print("  wrote fig6.png")
    print("  fig7/fig8: use 10_figures_7_8.py (corrected versions)")
    fig9(d, out / "fig9.png"); print("  wrote fig9.png")
    print("\nCopy fig5-fig9.png into latex/figures/ and update body.tex:")
    print("  figures/fig5.jpeg -> figures/fig5.png")
    print("Done.")


if __name__ == "__main__":
    main()
