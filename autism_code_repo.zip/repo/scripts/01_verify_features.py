# -*- coding: utf-8 -*-
"""
========================================================================
 STEP 2 VERIFICATION - Do current features match the paper's statistics?
========================================================================
Decides between:
  C1 = features file IS the one behind the paper; only the consensus
       bookkeeping ("9 patches") was stale.
       -> Safe to rewrite Section 4.5 / Table 5 / Section 5 with the
          new 20-patch numbers. Everything else in the paper stands.
  C2 = features file DIFFERS from the one behind the paper.
       -> Do NOT rewrite yet. Locate/regenerate the original features
          (see the .npz directory scan at the end).

Checks:
  1. Full-cohort Cohen's d per patch  vs paper's five principal values
  2. Welch t-test + Benjamini-Hochberg FDR landscape vs "16 sig, 15 R / 1 L"
  3. Laterality (R/L ratio, Wilcoxon)  vs 1.49x, p=0.0013, 13/16
  4. Leakage-safe 10-fold SVM (5 seeds) vs 67.31 +/- 9.5, best 84.21
  5. Scan project tree for other .npz files (older feature versions)
  +  Consensus re-run (primary seed + 50 reps) -> REWRITE PAYLOAD
  +  Optional: KKI / SDSU consensus sets + new intersections if their
     feature files are found.

Run:   python step2_verify_features.py
Then paste the FULL console output back into the chat.

Requires: numpy, scipy, scikit-learn (same env as your pipeline).
========================================================================
"""

import os
import sys
import json
import time
from pathlib import Path

import numpy as np
from scipy import stats

# ------------------------------------------------------------------ config
KNOWN_PATH = os.environ.get("ABIDE_FEATURES", "features/features_full3d_64patches.npz")
K, TAU, M, R = 50, 0.5, 10, 50
PRIMARY_SEED = 42
SVM_SEEDS = [42, 0, 1, 7, 123]

PAPER = {
    "principal_d":  {46: 0.584, 58: 0.482, 42: 0.464, 39: 0.444, 43: 0.404},
    "principal_q":  {46: 0.004, 58: 0.015, 42: 0.016, 39: 0.019, 43: 0.033},
    "fdr_total": 16, "fdr_right": 15, "fdr_left": 1,
    "acc_mean": 67.31, "acc_sd": 9.5, "acc_best": 84.21, "auc_mean": 0.696,
    "lat_ratio": 1.49, "lat_p": 0.0013, "lat_right_pairs": 13,
    "old_consensus_9": [18, 34, 39, 42, 43, 46, 47, 54, 58],
    "kki_expected_n": (56, 155),   # (ASD, HC)
    "sdsu_expected_n": (33, 25),
}

D_TOL = 0.010      # tolerance for matching principal Cohen's d values
ACC_TOL = 2.0      # percentage points, any seed

BAR = "=" * 72


# ------------------------------------------------------------------ helpers
def find_features(path_hint):
    p = Path(path_hint)
    if p.exists():
        return p
    # fallback: search near the script and in common locations
    roots = [Path.cwd(), Path(__file__).resolve().parent,
             Path.home() / "autism_project"]
    for root in roots:
        if root.exists():
            for f in root.rglob("features_full3d_64patches.npz"):
                return f
    return None


def load_xy(path, n_expected=None, asd_expected=None, name="dataset"):
    """Robustly pull (X: n x 512, y: n binary) out of an .npz file."""
    z = np.load(path, allow_pickle=True)
    X = y = None
    for k in z.files:
        arr = np.asarray(z[k])
        if arr.ndim == 2 and 512 in arr.shape:
            X = arr if arr.shape[1] == 512 else arr.T
        elif arr.ndim == 1 and len(np.unique(arr)) == 2:
            y = arr
    if X is None or y is None or X.shape[0] != y.shape[0]:
        # second pass: match y length to X rows
        if X is not None:
            for k in z.files:
                arr = np.asarray(z[k]).ravel()
                if arr.size == X.shape[0] and len(np.unique(arr)) == 2:
                    y = arr
                    break
    if X is None or y is None:
        raise RuntimeError("Could not identify X (n x 512) and binary y in %s "
                           "(keys: %s)" % (path, list(z.files)))
    u = np.unique(y)
    y = (y == u.max()).astype(int)   # assume larger label value = ASD = 1
    n1, n0 = int((y == 1).sum()), int((y == 0).sum())
    flipped = False
    if asd_expected is not None and n1 != asd_expected and n0 == asd_expected:
        y = 1 - y
        n1, n0 = n0, n1
        flipped = True
    print("  [%s] X: %s | labels: %d ones / %d zeros%s"
          % (name, X.shape, n1, n0, "  (labels FLIPPED to make 1=ASD)" if flipped else ""))
    if asd_expected is not None and n1 != asd_expected:
        print("  [WARN] expected %d ASD but found %d with label 1 - "
              "check label orientation manually." % (asd_expected, n1))
    return X.astype(float), y


def cohens_d_vec(X, y):
    """Eq. 10 of the paper: |mu_ASD - mu_HC| / sqrt((s1^2 + s0^2)/2), ddof=1."""
    a, b = X[y == 1], X[y == 0]
    v1 = a.var(axis=0, ddof=1)
    v0 = b.var(axis=0, ddof=1)
    sp = np.sqrt((v1 + v0) / 2.0)
    sp[sp == 0] = 1e-12
    return np.abs(a.mean(axis=0) - b.mean(axis=0)) / sp


def bh_adjust(p):
    p = np.asarray(p, dtype=float)
    n = p.size
    order = np.argsort(p)
    ranked = p[order]
    adj = ranked * n / (np.arange(n) + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.clip(adj, 0, 1)
    return out


def patch_stats(X, y):
    """Full-cohort per-patch max |d| and min BH-q over its 8 descriptors."""
    d = cohens_d_vec(X, y)
    _, pvals = stats.ttest_ind(X[y == 1], X[y == 0], equal_var=False)
    q = bh_adjust(pvals)
    pd = np.array([d[8 * p: 8 * p + 8].max() for p in range(64)])
    pq = np.array([q[8 * p: 8 * p + 8].min() for p in range(64)])
    return pd, pq


def hemi(p):
    return "R" if p % 4 >= 2 else "L"


def grid(p):
    return (p // 16, (p % 16) // 4, p % 4)


def consensus_run(X, y, seed, K=K, tau=TAU, M=M):
    from sklearn.model_selection import StratifiedKFold
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=seed)
    counts = np.zeros(64, dtype=int)
    for tr, _ in skf.split(X, y):
        d = cohens_d_vec(X[tr], y[tr])
        top = np.argsort(-d)[:K]
        for p in np.unique(top // 8):
            counts[p] += 1
    fp = counts / float(M)
    return fp, sorted(np.where(fp >= tau)[0].tolist())


def svm_cv(X, y, seed):
    from sklearn.model_selection import StratifiedKFold
    from sklearn.svm import SVC
    from sklearn.metrics import roc_auc_score
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=seed)
    accs, aucs = [], []
    for tr, te in skf.split(X, y):
        d = cohens_d_vec(X[tr], y[tr])
        top = np.argsort(-d)[:K]
        mu = X[tr][:, top].mean(axis=0)
        sd = X[tr][:, top].std(axis=0)
        sd[sd == 0] = 1.0
        Ztr = (X[tr][:, top] - mu) / sd
        Zte = (X[te][:, top] - mu) / sd
        clf = SVC(kernel="linear", C=0.5, class_weight="balanced")
        clf.fit(Ztr, y[tr])
        accs.append(clf.score(Zte, y[te]) * 100.0)
        try:
            aucs.append(roc_auc_score(y[te], clf.decision_function(Zte)))
        except ValueError:
            pass
    return np.array(accs), np.array(aucs)


# ============================================================== main
def main():
    print(BAR)
    print("STEP 2 VERIFICATION: features file vs published statistics")
    print(BAR)

    fpath = find_features(KNOWN_PATH)
    if fpath is None:
        print("[FATAL] features_full3d_64patches.npz not found. Edit KNOWN_PATH.")
        sys.exit(1)
    print("Features file: %s" % fpath)
    X, y = load_xy(fpath, asd_expected=79, name="NYU")

    # ---------------------------------------------------- check 1+2: d & FDR
    print("\n" + BAR)
    print("CHECK 1: Full-cohort Cohen's d vs paper's five principal values")
    print(BAR)
    pd, pq = patch_stats(X, y)
    d_ok = True
    print("  patch | paper d | computed d |  diff  | verdict")
    print("  ------+---------+------------+--------+--------")
    for p, dp in sorted(PAPER["principal_d"].items()):
        diff = pd[p] - dp
        ok = abs(diff) <= D_TOL
        d_ok &= ok
        print("   %4d |  %.3f  |   %.3f    | %+.3f | %s"
              % (p, dp, pd[p], diff, "PASS" if ok else "FAIL"))
    print("  -> principal-d match: %s (tolerance %.3f)"
          % ("YES" if d_ok else "NO", D_TOL))

    print("\n" + BAR)
    print("CHECK 2: FDR landscape (Welch + Benjamini-Hochberg, q<0.05)")
    print(BAR)
    sig = np.where(pq < 0.05)[0]
    n_r = sum(1 for p in sig if hemi(p) == "R")
    n_l = len(sig) - n_r
    print("  FDR-significant patches: %d (paper: %d)" % (len(sig), PAPER["fdr_total"]))
    print("  Right: %d (paper: %d) | Left: %d (paper: %d)"
          % (n_r, PAPER["fdr_right"], n_l, PAPER["fdr_left"]))
    print("  Significant patch IDs: %s" % list(map(int, sig)))
    fdr_ok = abs(len(sig) - PAPER["fdr_total"]) <= 1 and abs(n_r - PAPER["fdr_right"]) <= 1
    print("  -> FDR-landscape match: %s" % ("YES" if fdr_ok else "NO"))

    # ---------------------------------------------------- check 3: laterality
    print("\n" + BAR)
    print("CHECK 3: Laterality (16 matched pairs)")
    print(BAR)
    dL, dR = [], []
    for i in range(4):
        for j in range(4):
            base = 16 * i + 4 * j
            dL.append(max(pd[base + 0], pd[base + 1]))
            dR.append(max(pd[base + 2], pd[base + 3]))
    dL, dR = np.array(dL), np.array(dR)
    ratio = dR.mean() / dL.mean()
    right_pairs = int((dR > dL).sum())
    try:
        W, p_lat = stats.wilcoxon(dR, dL, alternative="greater")
    except Exception:
        W, p_lat = float("nan"), float("nan")
    print("  mean d Right: %.3f | mean d Left: %.3f | ratio: %.2fx (paper: %.2fx)"
          % (dR.mean(), dL.mean(), ratio, PAPER["lat_ratio"]))
    print("  right-dominant pairs: %d/16 (paper: %d/16)"
          % (right_pairs, PAPER["lat_right_pairs"]))
    print("  Wilcoxon one-sided: W=%.0f, p=%.4f (paper: p=%.4f)"
          % (W, p_lat, PAPER["lat_p"]))

    # ---------------------------------------------------- check 4: SVM
    print("\n" + BAR)
    print("CHECK 4: Leakage-safe 10-fold SVM (K=50, C=0.5, balanced weights)")
    print(BAR)
    acc_ok = False
    svm_rows = []
    for s in SVM_SEEDS:
        accs, aucs = svm_cv(X, y, s)
        row = dict(seed=s, mean=float(accs.mean()), sd=float(accs.std(ddof=1)),
                   best=float(accs.max()),
                   auc=float(np.mean(aucs)) if len(aucs) else float("nan"))
        svm_rows.append(row)
        hit = abs(row["mean"] - PAPER["acc_mean"]) <= ACC_TOL
        acc_ok |= hit
        print("  seed %4d: mean %.2f%% +/- %.1f | best %.2f%% | AUC %.3f %s"
              % (s, row["mean"], row["sd"], row["best"], row["auc"],
                 "<-- within %.1f pts of 67.31" % ACC_TOL if hit else ""))
    print("  paper:      mean 67.31%% +/- 9.5 | best 84.21%% | AUC 0.696")
    print("  -> accuracy consistent with paper on >=1 seed: %s"
          % ("YES" if acc_ok else "NO"))

    # ---------------------------------------------------- consensus payload
    print("\n" + BAR)
    print("CONSENSUS RE-RUN (for the rewrite payload)")
    print(BAR)
    fp_primary, P_primary = consensus_run(X, y, PRIMARY_SEED)
    print("  Primary run (seed=%d): %d patches: %s"
          % (PRIMARY_SEED, len(P_primary), P_primary))
    sel = np.zeros((R, 64), dtype=bool)
    for rep in range(R):
        _, Pr = consensus_run(X, y, seed=rep)
        sel[rep, Pr] = True
    rec = sel.sum(axis=0)
    always = sorted(int(p) for p in np.where(sel.all(axis=0))[0])
    sizes = sel.sum(axis=1)
    print("  Across %d reps: mean size %.2f +/- %.2f | in ALL reps: %d patches: %s"
          % (R, sizes.mean(), sizes.std(ddof=1), len(always), always))
    principal_ok = all(p in P_primary for p in PAPER["principal_d"])
    print("  Five principal biomarkers in primary consensus: %s"
          % ("YES" if principal_ok else "NO"))

    print("\n  Per-patch table (primary f_p >= %.1f):" % TAU)
    print("  patch | (i,j,k) | hemi |  f_p | in all %d reps | max d | FDR q   | FDR sig" % R)
    print("  ------+---------+------+------+----------------+-------+---------+--------")
    payload_rows = []
    for p in P_primary:
        row = dict(patch=int(p), grid=grid(p), hemi=hemi(p),
                   fp=float(fp_primary[p]), reps=int(rec[p]),
                   always=bool(sel.all(axis=0)[p]),
                   dmax=float(pd[p]), q=float(pq[p]), sig=bool(pq[p] < 0.05))
        payload_rows.append(row)
        print("   %4d | %s |  %s   | %.2f |      %2d/%d     | %.3f | %.4f | %s"
              % (p, grid(p), hemi(p), fp_primary[p], rec[p], R,
                 pd[p], pq[p], "yes" if pq[p] < 0.05 else "no"))

    # ---------------------------------------------------- cohorts (optional)
    print("\n" + BAR)
    print("KKI / SDSU (optional - only if their feature files are found)")
    print(BAR)
    root = fpath.resolve().parents[1] if len(fpath.resolve().parents) > 1 else fpath.parent
    cohorts = {}
    for f in root.rglob("*.npz"):
        low = f.name.lower()
        for tag, exp in (("kki", PAPER["kki_expected_n"]),
                         ("sdsu", PAPER["sdsu_expected_n"])):
            if tag in low and tag not in cohorts:
                try:
                    Xc, yc = load_xy(f, asd_expected=exp[0], name=tag.upper())
                    _, Pc = consensus_run(Xc, yc, PRIMARY_SEED)
                    cohorts[tag] = dict(file=str(f), consensus=Pc)
                    print("  %s consensus (%d patches): %s"
                          % (tag.upper(), len(Pc), Pc))
                except Exception as e:
                    print("  [%s] found %s but could not process: %s"
                          % (tag.upper(), f.name, e))
    if {"kki", "sdsu"} <= set(cohorts):
        S_nyu = set(P_primary)
        S_kki = set(cohorts["kki"]["consensus"])
        S_sdsu = set(cohorts["sdsu"]["consensus"])
        print("  NEW NYU n KKI          : %s" % sorted(S_nyu & S_kki))
        print("  NEW NYU n SDSU         : %s" % sorted(S_nyu & S_sdsu))
        print("  NEW NYU n KKI n SDSU   : %s" % sorted(S_nyu & S_kki & S_sdsu))
        print("  (old paper 3-way was {18, 34, 39, 43, 46})")
    elif not cohorts:
        print("  No KKI/SDSU .npz found under %s - send their paths/lists "
              "separately for the Section 5 rewrite." % root)

    # ---------------------------------------------------- directory scan
    print("\n" + BAR)
    print("ALL .npz FILES UNDER PROJECT ROOT (oldest first) - hunt for the")
    print("original features file if verdict is C2")
    print(BAR)
    npzs = sorted(root.rglob("*.npz"), key=lambda q: q.stat().st_mtime)
    for f in npzs:
        st = f.stat()
        print("  %s | %8.1f MB | %s"
              % (time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime)),
                 st.st_size / 1e6, f))

    # ---------------------------------------------------- verdict
    print("\n" + BAR)
    print("VERDICT")
    print(BAR)
    if d_ok and fdr_ok:
        print("  C1 - CONFIRMED: the current features file reproduces the")
        print("  paper's effect sizes and FDR landscape%s."
              % (" and its SVM accuracy" if acc_ok else
                 " (SVM mean differs - note it, but d/FDR are decisive)"))
        print("  => The published '9 consensus patches' was stale bookkeeping.")
        print("  => Rewrite Section 4.5, Table 5, Figure 5, Abstract counts,")
        print("     and Section 5 intersections using the payload below.")
    elif not d_ok:
        print("  C2 - the current features do NOT reproduce the paper's")
        print("  principal effect sizes. Do NOT rewrite yet. Check the .npz")
        print("  scan above for an older features file (or regenerate features")
        print("  exactly per Methods 3.3-3.4), then re-run this script on it.")
    else:
        print("  MIXED - principal d values match but the FDR landscape does")
        print("  not. Paste the full output; this needs a closer look before")
        print("  any rewrite.")

    # ---------------------------------------------------- payload dump
    print("\n" + BAR)
    print("REWRITE PAYLOAD (paste everything below back into the chat)")
    print(BAR)
    payload = dict(
        verdict=("C1" if (d_ok and fdr_ok) else ("C2" if not d_ok else "MIXED")),
        primary_seed=PRIMARY_SEED,
        primary_consensus=P_primary,
        n_reps=R, mean_size=float(sizes.mean()), sd_size=float(sizes.std(ddof=1)),
        always_recovered=always,
        patches=payload_rows,
        fdr_significant=sorted(int(p) for p in sig),
        fdr_split=dict(total=int(len(sig)), right=int(n_r), left=int(n_l)),
        laterality=dict(ratio=float(ratio), right_pairs=right_pairs,
                        W=float(W), p=float(p_lat)),
        svm=svm_rows,
        cohorts={k: v["consensus"] for k, v in cohorts.items()},
    )
    print(json.dumps(payload, indent=2))
    print("\nDone.")


if __name__ == "__main__":
    main()
