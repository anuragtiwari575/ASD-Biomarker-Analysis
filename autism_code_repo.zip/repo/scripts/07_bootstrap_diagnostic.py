# -*- coding: utf-8 -*-
"""
step9_bootstrap.py - settles whether the reported bootstrap CI is really
subject-aware.

THE PROBLEM
  The paper reports mean accuracy 67.31% with a 95% bootstrap CI of
  [64.0%, 80.5%]. The point estimate sits 3.3 points above the lower bound
  but 13.2 points below the upper bound. A percentile bootstrap of a mean
  should not be that lopsided. The usual cause is duplicate leakage: when
  subjects are resampled with replacement and the resampled matrix is then
  passed to a plain StratifiedKFold, copies of the same subject land in both
  the training and test folds, so the model is partly tested on subjects it
  trained on, and resampled accuracies inflate.

WHAT THIS SCRIPT DOES
  Computes the bootstrap CI twice on identical resamples:
    (A) NAIVE  - plain StratifiedKFold on the resampled matrix (duplicates
                 free to split across folds). This is what the code most
                 likely did.
    (B) GROUPED- StratifiedGroupKFold with groups = original subject index,
                 so every copy of a subject stays in the same fold. This is
                 what "subject-aware" must mean.
  If (A) reproduces [64.0, 80.5] and (B) does not, the published CI is the
  leaky one and must be replaced by (B).

RUN:  python step9_bootstrap.py > bootstrap.txt 2>&1
      (takes a few minutes: 2 x B x 10 fits)
"""

import os
import sys
from pathlib import Path

import numpy as np

# Path to the extracted feature file. Override without editing this script:
#   Linux/macOS:  export ABIDE_FEATURES=/path/to/features_full3d_64patches.npz
#   Windows:      set ABIDE_FEATURES=C:\path\to\features_full3d_64patches.npz
NYU_PATH = os.environ.get(
    "ABIDE_FEATURES",
    "features/features_full3d_64patches.npz",
)
SEED, K, M = 42, 50, 10
B = 500
REPORTED = (64.0, 80.5)
BAR = "=" * 72


def load(path):
    z = np.load(path, allow_pickle=True)
    X = y = None
    for k in z.files:
        a = np.asarray(z[k])
        if a.ndim == 2 and 512 in a.shape:
            X = a if a.shape[1] == 512 else a.T
    for k in z.files:
        a = np.asarray(z[k]).ravel()
        if X is not None and a.size == X.shape[0] and len(np.unique(a)) == 2:
            y = a
    u = np.unique(y)
    y = (y == u.max()).astype(int)
    if (y == 1).sum() != 79 and (y == 0).sum() == 79:
        y = 1 - y
    return X.astype(float), y


def cohens_d(X, y):
    a, b = X[y == 1], X[y == 0]
    sp = np.sqrt((a.var(0, ddof=1) + b.var(0, ddof=1)) / 2.0)
    sp[sp == 0] = 1e-12
    return np.abs(a.mean(0) - b.mean(0)) / sp


def cv_accuracy(X, y, groups, splitter):
    from sklearn.preprocessing import StandardScaler
    from sklearn.svm import SVC
    accs = []
    it = (splitter.split(X, y, groups) if groups is not None
          else splitter.split(X, y))
    for tr, te in it:
        if len(np.unique(y[tr])) < 2 or len(te) == 0:
            continue
        d = cohens_d(X[tr], y[tr])
        top = np.argsort(-d)[:K]
        sc = StandardScaler().fit(X[tr][:, top])
        clf = SVC(kernel="linear", C=0.5, class_weight="balanced").fit(
            sc.transform(X[tr][:, top]), y[tr])
        accs.append((clf.predict(sc.transform(X[te][:, top])) == y[te]).mean())
    return float(np.mean(accs)) if accs else np.nan


def stratified_resample(y, rng):
    """Resample with replacement within each class (preserves ASD/HC ratio)."""
    idx = []
    for cls in (0, 1):
        pool = np.where(y == cls)[0]
        idx.append(rng.choice(pool, size=pool.size, replace=True))
    return np.concatenate(idx)


def main():
    print(BAR)
    print("STEP 9 - IS THE BOOTSTRAP CI SUBJECT-AWARE?")
    print(BAR)
    p = Path(NYU_PATH)
    if not p.exists():
        hits = list(Path.home().rglob("features_full3d_64patches.npz"))
        if not hits:
            print("[FATAL] features not found; edit NYU_PATH."); sys.exit(1)
        p = hits[0]
    X, y = load(p)
    print("  data: %s | ASD %d | HC %d" % (X.shape, (y == 1).sum(), (y == 0).sum()))
    print("  reported CI in the manuscript: [%.1f, %.1f]" % REPORTED)

    from sklearn.model_selection import StratifiedKFold
    try:
        from sklearn.model_selection import StratifiedGroupKFold
        grouped_cls = StratifiedGroupKFold
        grouped_name = "StratifiedGroupKFold"
    except ImportError:
        from sklearn.model_selection import GroupKFold
        grouped_cls = GroupKFold
        grouped_name = "GroupKFold (stratified variant unavailable)"
    print("  grouped splitter: %s" % grouped_name)

    point = cv_accuracy(X, y, None,
                        StratifiedKFold(n_splits=M, shuffle=True,
                                        random_state=SEED))
    print("  point estimate (no bootstrap): %.2f%%\n" % (100 * point))

    rng_master = np.random.RandomState(SEED)
    naive, grouped = [], []
    for b in range(B):
        rng = np.random.RandomState(rng_master.randint(0, 10 ** 6))
        idx = stratified_resample(y, rng)
        Xb, yb, gb = X[idx], y[idx], idx  # gb = original subject id

        naive.append(cv_accuracy(
            Xb, yb, None,
            StratifiedKFold(n_splits=M, shuffle=True, random_state=SEED)))
        try:
            sp = (grouped_cls(n_splits=M, shuffle=True, random_state=SEED)
                  if grouped_name.startswith("Stratified")
                  else grouped_cls(n_splits=M))
            grouped.append(cv_accuracy(Xb, yb, gb, sp))
        except Exception as e:
            grouped.append(np.nan)
            if b == 0:
                print("  [warn] grouped split failed: %s" % e)
        if (b + 1) % 100 == 0:
            print("  ... %d/%d resamples" % (b + 1, B))

    def summarize(vals, name):
        v = np.array([x for x in vals if not np.isnan(x)])
        lo, hi = np.percentile(v, [2.5, 97.5])
        print("\n  %s" % name)
        print("    mean %.2f%% | median %.2f%% | 95%% CI [%.1f, %.1f] | width %.1f"
              % (100 * v.mean(), 100 * np.median(v), 100 * lo, 100 * hi,
                 100 * (hi - lo)))
        print("    point estimate sits %.1f above lower / %.1f below upper"
              % (100 * point - 100 * lo, 100 * hi - 100 * point))
        return 100 * lo, 100 * hi

    print("\n" + BAR)
    print("RESULTS")
    print(BAR)
    nlo, nhi = summarize(naive, "(A) NAIVE - duplicates split across folds")
    glo, ghi = summarize(grouped, "(B) GROUPED - all copies of a subject in one fold")

    print("\n" + BAR)
    print("VERDICT")
    print(BAR)
    close = lambda a, b: abs(a - b) < 1.5
    if close(nlo, REPORTED[0]) and close(nhi, REPORTED[1]):
        print("  (A) reproduces the published interval -> the published CI is")
        print("      the NAIVE one. It is optimistic and must be replaced by")
        print("      (B), and the word 'subject-aware' must be justified by")
        print("      the grouped procedure.")
    elif close(glo, REPORTED[0]) and close(ghi, REPORTED[1]):
        print("  (B) reproduces the published interval -> the bootstrap WAS")
        print("      subject-aware. Keep the numbers and just add the explicit")
        print("      sentence describing the grouping.")
    else:
        print("  Neither reproduces [%.1f, %.1f] exactly. Report the grouped")
        print("  interval (B) and note the pinned-seed protocol." % REPORTED)
    print("\n  Paste-ready replacement for Section 4.2 / abstract if (B) is used:")
    print("    95%% CI [%.1f%%, %.1f%%]" % (glo, ghi))
    print("\nDone.")


if __name__ == "__main__":
    main()
