# -*- coding: utf-8 -*-
"""
========================================================================
 STEP 3 - FINAL NUMBERS FOR THE MANUSCRIPT REWRITE  (C1 confirmed)
========================================================================
Fixes the FDR bug from step 2 (NaN p-values from constant/background
features poisoned the Benjamini-Hochberg step) and produces every number
needed to rewrite Sections 4.5-4.8 and Section 5:

  A. NYU: real FDR q-values (all 64 patches), significant set + L/R split,
     and a Table5-vs-Table8 check (which q set was the "real" run).
  B. NYU: new PRINCIPAL candidate set = primary consensus  FDR-significant,
     ranked by effect size (this becomes the new Table 7 skeleton).
  C. KKI / SDSU: per-cohort patch d + q, laterality (verify Table 14),
     SVM seed=42 (verify Table 15), the five-biomarker d check (Table 13).
  D. All three cohorts: primary-seed consensus + 50-rep stability core.
  E. New intersections, on primary sets AND on stability cores.
  F. Final JSON payload for the rewrite.

Run:   python step3_final_numbers.py > final_numbers.txt 2>&1
Then paste final_numbers.txt back in full.
========================================================================
"""

import json
import os
import sys
import time
from pathlib import Path

import numpy as np
from scipy import stats

# ------------------------------------------------------------------ config
# Path to the extracted feature file. Override without editing this script:
#   Linux/macOS:  export ABIDE_FEATURES=/path/to/features_full3d_64patches.npz
#   Windows:      set ABIDE_FEATURES=C:\path\to\features_full3d_64patches.npz
NYU_PATH = os.environ.get(
    "ABIDE_FEATURES",
    "features/features_full3d_64patches.npz",
)
K, TAU, M, R = 50, 0.5, 10, 50
PRIMARY_SEED = 42

PAPER = {
    "t5_q":  {46: 0.004, 58: 0.015, 42: 0.016, 39: 0.019, 43: 0.033},
    "t8_q":  {46: 0.003, 58: 0.012, 42: 0.014, 39: 0.016, 43: 0.030},
    "fdr_total": 16, "fdr_right": 15, "fdr_left": 1,
    "t13": {46: {"kki": 0.23, "sdsu": 0.62},
            39: {"kki": 0.28, "sdsu": 0.61},
            43: {"kki": 0.28, "sdsu": 0.36},
            42: {"kki": 0.22, "sdsu": 0.13},
            58: {"kki": 0.08, "sdsu": 0.25}},
    "t14": {"kki":  {"ratio": 0.92, "pairs": 8, "p": 0.85},
            "sdsu": {"ratio": 1.12, "pairs": 9, "p": 0.16}},
    "t15": {"kki":  {"acc": 52.0, "auc": 0.470},
            "sdsu": {"acc": 52.7, "auc": 0.590}},
    "old_nyu_9": [18, 34, 39, 42, 43, 46, 47, 54, 58],
}

BAR = "=" * 72


# ------------------------------------------------------------------ helpers
def load_xy(path, asd_expected=None, name="dataset"):
    z = np.load(path, allow_pickle=True)
    X = y = None
    for k in z.files:
        arr = np.asarray(z[k])
        if arr.ndim == 2 and 512 in arr.shape:
            X = arr if arr.shape[1] == 512 else arr.T
        elif arr.ndim == 1 and len(np.unique(arr)) == 2:
            y = arr
    if X is not None and (y is None or y.shape[0] != X.shape[0]):
        for k in z.files:
            arr = np.asarray(z[k]).ravel()
            if arr.size == X.shape[0] and len(np.unique(arr)) == 2:
                y = arr
                break
    if X is None or y is None:
        raise RuntimeError("Could not identify X/y in %s" % path)
    u = np.unique(y)
    y = (y == u.max()).astype(int)
    if asd_expected is not None and (y == 1).sum() != asd_expected \
            and (y == 0).sum() == asd_expected:
        y = 1 - y
    print("  [%s] X: %s | ASD(1): %d | HC(0): %d"
          % (name, X.shape, (y == 1).sum(), (y == 0).sum()))
    return X.astype(float), y


def cohens_d_vec(X, y):
    a, b = X[y == 1], X[y == 0]
    v1 = a.var(axis=0, ddof=1)
    v0 = b.var(axis=0, ddof=1)
    sp = np.sqrt((v1 + v0) / 2.0)
    sp[sp == 0] = 1e-12
    return np.abs(a.mean(axis=0) - b.mean(axis=0)) / sp


def bh_adjust(p):
    p = np.asarray(p, dtype=float)
    n = p.size
    order = np.argsort(p)
    ranked = p[order]
    adj = ranked * n / (np.arange(n) + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.clip(adj, 0, 1)
    return out


def patch_stats_fixed(X, y):
    """Full-cohort per-patch max |d| and min BH-q, with NaN-safe FDR."""
    d = cohens_d_vec(X, y)
    _, pvals = stats.ttest_ind(X[y == 1], X[y == 0], equal_var=False)
    pvals = np.asarray(pvals, dtype=float)
    n_nan = int(np.isnan(pvals).sum())
    pvals = np.where(np.isnan(pvals), 1.0, pvals)   # undefined -> p = 1.0
    q = bh_adjust(pvals)                            # joint over all 512
    pd_ = np.array([np.nanmax(d[8 * p: 8 * p + 8]) for p in range(64)])
    pq_ = np.array([q[8 * p: 8 * p + 8].min() for p in range(64)])
    return pd_, pq_, n_nan


def hemi(p):
    return "R" if p % 4 >= 2 else "L"


def grid(p):
    return (p // 16, (p % 16) // 4, p % 4)


def laterality(pd_):
    dL, dR = [], []
    for i in range(4):
        for j in range(4):
            base = 16 * i + 4 * j
            dL.append(max(pd_[base + 0], pd_[base + 1]))
            dR.append(max(pd_[base + 2], pd_[base + 3]))
    dL, dR = np.array(dL), np.array(dR)
    try:
        W, p = stats.wilcoxon(dR, dL, alternative="greater")
    except Exception:
        W, p = float("nan"), float("nan")
    return dict(ratio=float(dR.mean() / dL.mean()),
                pairs=int((dR > dL).sum()), W=float(W), p=float(p),
                mean_R=float(dR.mean()), mean_L=float(dL.mean()))


def consensus_run(X, y, seed):
    from sklearn.model_selection import StratifiedKFold
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=seed)
    counts = np.zeros(64, dtype=int)
    for tr, _ in skf.split(X, y):
        d = cohens_d_vec(X[tr], y[tr])
        top = np.argsort(-d)[:K]
        for p in np.unique(top // 8):
            counts[p] += 1
    fp = counts / float(M)
    return fp, sorted(np.where(fp >= TAU)[0].tolist())


def stability(X, y):
    sel = np.zeros((R, 64), dtype=bool)
    for rep in range(R):
        _, Pr = consensus_run(X, y, seed=rep)
        sel[rep, Pr] = True
    return sel.sum(axis=0), sorted(int(p) for p in np.where(sel.all(axis=0))[0]), \
        sel.sum(axis=1)


def svm_cv(X, y, seed):
    from sklearn.model_selection import StratifiedKFold
    from sklearn.svm import SVC
    from sklearn.metrics import roc_auc_score
    skf = StratifiedKFold(n_splits=M, shuffle=True, random_state=seed)
    accs, aucs = [], []
    for tr, te in skf.split(X, y):
        d = cohens_d_vec(X[tr], y[tr])
        top = np.argsort(-d)[:K]
        mu = X[tr][:, top].mean(axis=0)
        sd = X[tr][:, top].std(axis=0)
        sd[sd == 0] = 1.0
        clf = SVC(kernel="linear", C=0.5, class_weight="balanced")
        clf.fit((X[tr][:, top] - mu) / sd, y[tr])
        Zte = (X[te][:, top] - mu) / sd
        accs.append(clf.score(Zte, y[te]) * 100.0)
        try:
            aucs.append(roc_auc_score(y[te], clf.decision_function(Zte)))
        except ValueError:
            pass
    return float(np.mean(accs)), float(np.mean(aucs)) if aucs else float("nan")


def analyse_cohort(name, X, y):
    pd_, pq_, n_nan = patch_stats_fixed(X, y)
    fp, Pprim = consensus_run(X, y, PRIMARY_SEED)
    rec, core, sizes = stability(X, y)
    return dict(name=name, pd=pd_, pq=pq_, n_nan=n_nan, fp=fp,
                primary=Pprim, rec=rec, core=core,
                mean_size=float(sizes.mean()), sd_size=float(sizes.std(ddof=1)),
                lat=laterality(pd_))


# ============================================================== main
def main():
    print(BAR)
    print("STEP 3 - FINAL NUMBERS (FDR fixed, full cross-cohort rebuild)")
    print(BAR)

    nyu_path = Path(NYU_PATH)
    if not nyu_path.exists():
        hits = list(Path.home().rglob("features_full3d_64patches.npz"))
        if not hits:
            print("[FATAL] NYU features file not found. Edit NYU_PATH.")
            sys.exit(1)
        nyu_path = hits[0]
    print("NYU features: %s" % nyu_path)
    Xn, yn = load_xy(nyu_path, asd_expected=79, name="NYU")
    nyu = analyse_cohort("NYU", Xn, yn)

    # ------------------------------------------- A. NYU FDR landscape
    print("\n" + BAR)
    print("A. NYU FDR LANDSCAPE (NaN-safe: %d undefined feature tests set to p=1.0)"
          % nyu["n_nan"])
    print(BAR)
    sig = sorted(int(p) for p in np.where(nyu["pq"] < 0.05)[0])
    n_r = sum(1 for p in sig if hemi(p) == "R")
    print("  FDR-significant patches: %d (paper: %d) | Right: %d (paper: %d) "
          "| Left: %d (paper: %d)"
          % (len(sig), PAPER["fdr_total"], n_r, PAPER["fdr_right"],
             len(sig) - n_r, PAPER["fdr_left"]))
    print("  Significant patch IDs: %s" % sig)
    print("\n  Which published q-set does this run match? (five old principals)")
    print("  patch | computed q | Table 5 q | Table 8 q | closer to")
    print("  ------+------------+-----------+-----------+----------")
    for p in sorted(PAPER["t5_q"]):
        cq = nyu["pq"][p]
        d5 = abs(cq - PAPER["t5_q"][p])
        d8 = abs(cq - PAPER["t8_q"][p])
        print("   %4d |   %.4f   |   %.3f   |   %.3f   | Table %s"
              % (p, cq, PAPER["t5_q"][p], PAPER["t8_q"][p],
                 "5" if d5 <= d8 else "8"))

    # ------------------------------------------- B. new principal set
    print("\n" + BAR)
    print("B. NEW PRINCIPAL CANDIDATE SET  (primary consensus  FDR q<0.05)")
    print(BAR)
    principal = [p for p in nyu["primary"] if nyu["pq"][p] < 0.05]
    principal_core = [p for p in principal if p in nyu["core"]]
    principal.sort(key=lambda p: -nyu["pd"][p])
    print("  Primary consensus (seed %d): %d patches: %s"
          % (PRIMARY_SEED, len(nyu["primary"]), nyu["primary"]))
    print("  Stability core (all %d reps): %d patches: %s"
          % (R, len(nyu["core"]), nyu["core"]))
    print("  NEW principal set: %d patches (ranked by d):" % len(principal))
    print("  patch | (i,j,k) | hemi | f_p  | core | max d | FDR q  | needs atlas label?")
    print("  ------+---------+------+------+------+-------+--------+-------------------")
    OLD5 = set(PAPER["t5_q"])
    for p in principal:
        print("   %4d | %s |  %s   | %.2f | %s  | %.3f | %.4f | %s"
              % (p, grid(p), hemi(p), nyu["fp"][p],
                 "yes" if p in nyu["core"] else "NO ",
                 nyu["pd"][p], nyu["pq"][p],
                 "already have" if p in OLD5 else "YES - run labeling script"))
    print("  (principal AND in stability core: %d patches: %s)"
          % (len(principal_core), sorted(principal_core)))

    # ------------------------------------------- C+D. external cohorts
    print("\n" + BAR)
    print("C/D. EXTERNAL COHORTS")
    print(BAR)
    root = nyu_path.resolve().parents[1] if len(nyu_path.resolve().parents) > 1 \
        else nyu_path.parent
    cohorts = {}
    expected = {"kki": 56, "sdsu": 33}
    for f in sorted(root.rglob("*.npz")):
        low = f.name.lower()
        for tag in ("kki", "sdsu"):
            if tag in low and tag not in cohorts:
                try:
                    Xc, yc = load_xy(f, asd_expected=expected[tag],
                                     name=tag.upper())
                    cohorts[tag] = analyse_cohort(tag.upper(), Xc, yc)
                    cohorts[tag]["svm"] = svm_cv(Xc, yc, PRIMARY_SEED)
                except Exception as e:
                    print("  [%s] %s -> ERROR: %s" % (tag.upper(), f.name, e))

    for tag, c in cohorts.items():
        pap14 = PAPER["t14"][tag]
        pap15 = PAPER["t15"][tag]
        print("\n  --- %s ---" % c["name"])
        print("  Primary consensus (%d): %s" % (len(c["primary"]), c["primary"]))
        print("  Stability core (all %d reps) (%d): %s" % (R, len(c["core"]), c["core"]))
        print("  Mean consensus size over %d reps: %.2f +/- %.2f"
              % (R, c["mean_size"], c["sd_size"]))
        print("  FDR-significant patches (own cohort): %s"
              % sorted(int(p) for p in np.where(c["pq"] < 0.05)[0]))
        print("  Laterality: ratio %.2fx (paper %.2fx) | right pairs %d/16 "
              "(paper %d/16) | p=%.3f (paper %.2f)"
              % (c["lat"]["ratio"], pap14["ratio"], c["lat"]["pairs"],
                 pap14["pairs"], c["lat"]["p"], pap14["p"]))
        print("  SVM seed=%d: acc %.1f%% (paper %.1f%%) | AUC %.3f (paper %.3f)"
              % (PRIMARY_SEED, c["svm"][0], pap15["acc"],
                 c["svm"][1], pap15["auc"]))
        print("  Five-biomarker d check (Table 13):")
        print("    patch | computed d | paper d")
        for p in sorted(PAPER["t13"]):
            print("     %4d |   %.3f    |  %.2f" % (p, c["pd"][p],
                                                    PAPER["t13"][p][tag]))

    # ------------------------------------------- E. intersections
    print("\n" + BAR)
    print("E. NEW CROSS-COHORT INTERSECTIONS")
    print(BAR)
    if {"kki", "sdsu"} <= set(cohorts):
        for basis in ("primary", "core"):
            Sn = set(nyu[basis])
            Sk = set(cohorts["kki"][basis])
            Ss = set(cohorts["sdsu"][basis])
            print("\n  Basis: %s sets" % basis.upper())
            print("    NYU n KKI        (%2d): %s" % (len(Sn & Sk), sorted(Sn & Sk)))
            print("    NYU n SDSU       (%2d): %s" % (len(Sn & Ss), sorted(Sn & Ss)))
            print("    KKI n SDSU       (%2d): %s" % (len(Sk & Ss), sorted(Sk & Ss)))
            print("    NYU n KKI n SDSU (%2d): %s"
                  % (len(Sn & Sk & Ss), sorted(Sn & Sk & Ss)))
            print("    Recovery of NYU set: KKI %d/%d | SDSU %d/%d | both %d/%d"
                  % (len(Sn & Sk), len(Sn), len(Sn & Ss), len(Sn),
                     len(Sn & Sk & Ss), len(Sn)))
            pr = [p for p in principal if p in Sk and p in Ss]
            print("    NEW principal biomarkers recovered in BOTH: %s" % pr)
    else:
        print("  KKI/SDSU not found - primary-basis intersections from step 2 stand.")

    # ------------------------------------------- F. payload
    print("\n" + BAR)
    print("F. REWRITE PAYLOAD (paste everything below)")
    print(BAR)
    payload = dict(
        verdict="C1-final",
        nyu=dict(
            primary=nyu["primary"], core=nyu["core"],
            mean_size=nyu["mean_size"], sd_size=nyu["sd_size"],
            fdr_sig=sig, fdr_split=dict(total=len(sig), right=n_r,
                                        left=len(sig) - n_r),
            principal=[dict(patch=int(p), grid=grid(p), hemi=hemi(p),
                            fp=float(nyu["fp"][p]),
                            core=bool(p in nyu["core"]),
                            d=round(float(nyu["pd"][p]), 3),
                            q=round(float(nyu["pq"][p]), 4))
                       for p in principal],
            all_consensus=[dict(patch=int(p), fp=float(nyu["fp"][p]),
                                core=bool(p in nyu["core"]),
                                d=round(float(nyu["pd"][p]), 3),
                                q=round(float(nyu["pq"][p]), 4))
                           for p in nyu["primary"]],
            laterality=nyu["lat"], n_nan_features=nyu["n_nan"],
        ),
        cohorts={tag: dict(primary=c["primary"], core=c["core"],
                           mean_size=c["mean_size"],
                           fdr_sig=sorted(int(p) for p in
                                          np.where(c["pq"] < 0.05)[0]),
                           d_five={str(p): round(float(c["pd"][p]), 3)
                                   for p in PAPER["t13"]},
                           laterality=c["lat"], svm=c["svm"])
                 for tag, c in cohorts.items()},
    )
    print(json.dumps(payload, indent=2))
    print("\nDone. %s" % time.strftime("%Y-%m-%d %H:%M"))


if __name__ == "__main__":
    main()
