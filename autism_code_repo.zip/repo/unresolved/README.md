# Unresolved: Harvard-Oxford anatomical labelling

Two attempts to assign atlas labels to all 20 consensus patches. **Neither
output is used in the manuscript.**

- `atlas_labels_attempt1.py` — point query at each patch centroid, calibrated
  against the five labels already established for patches 39, 42, 43, 46 and
  58. Reproduced 3 of 5, so it stops without emitting labels.
- `atlas_labels_attempt2.py` — volumetric modal label over each 32^3 patch
  block, testing only the four orientations the indexing scheme permits.
  Reproduced 2 of 5, so it also stops.

Both scripts refuse to emit labels they cannot validate. The failure is in the
grid-to-MNI bounding-box assumption, not in the atlas query: both attempts
place the patch grid on the MNI brain bounding box, whereas the analysis grid
comes from resampling each subject's native field of view.

**What these attempts did validate:** the left-right axis. Every white-matter
and subcortical hit landed on the correct hemisphere (k = 1 gave left, k in
{2,3} gave right), so the hemisphere indexing and the laterality analysis are
sound. Only the superior-inferior and anterior-posterior alignment is
unresolved.

Resolving this requires the per-subject affine transforms used in the original
labelling step, which map the analysis grid to MNI directly instead of
assuming a bounding box.
