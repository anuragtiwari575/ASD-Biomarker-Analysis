# -*- coding: utf-8 -*-
"""
step4_labels.py - Harvard-Oxford labels for all 20 consensus patches.

WHY THIS IS SAFE:
  The 4x4x4 patch grid lives in a resampled native-space volume, so the
  grid->MNI axis convention is not obvious from the data alone. Instead of
  guessing, this script enumerates every plausible axis permutation and
  flip, and scores each one against the FIVE labels you already published
  and trust:
        46 -> Right Frontal Pole
        58 -> Right Precentral Gyrus
        39 -> Right Postcentral Gyrus
        42 -> Right Middle Frontal Gyrus
        43 -> Right Cerebral White Matter
  Only a mapping that reproduces those five is used to label the other 15.
  If no mapping reproduces them, the script says so and labels nothing --
  better than silently emitting wrong anatomy.

REQUIREMENTS:
    pip install nilearn nibabel
  (first run downloads the Harvard-Oxford atlas, ~30 MB, needs internet)

RUN:
    python step4_labels.py > labels.txt 2>&1
  Then paste labels.txt back.
"""

import itertools
import sys

import numpy as np

# ----------------------------------------------------------------- config
CONSENSUS = [10, 46, 30, 38, 62, 22, 58, 9, 42, 26, 39, 27, 23, 43,
             6, 14, 5, 57, 49, 41]

# labels you already have (used ONLY to calibrate the mapping)
KNOWN = {
    46: "frontal pole",
    58: "precentral",
    39: "postcentral",
    42: "middle frontal",
    43: "white matter",
}

BAR = "=" * 72


def patch_ijk(p):
    """p = 16i + 4j + k, i=SI, j=AP, k=LR (k in {0,1} left, {2,3} right)."""
    return p // 16, (p % 16) // 4, p % 4


def hemi(p):
    return "R" if p % 4 >= 2 else "L"


def load_atlas():
    from nilearn import datasets, image
    cort = datasets.fetch_atlas_harvard_oxford("cort-maxprob-thr25-2mm")
    sub = datasets.fetch_atlas_harvard_oxford("sub-maxprob-thr25-2mm")
    return cort, sub, image


def label_at_mni(coord, cort, sub, image, max_radius=8):
    """Return the Harvard-Oxford label at an MNI coordinate, expanding the
    search radius (2 -> 4 -> 8 mm) if the point is unlabeled."""
    import nibabel as nib

    for atlas, names in ((cort, cort.labels), (sub, sub.labels)):
        img = atlas.maps if hasattr(atlas.maps, "get_fdata") else nib.load(atlas.maps)
        data = np.asarray(img.get_fdata()).astype(int)
        inv = np.linalg.inv(img.affine)
        vox = inv @ np.array([coord[0], coord[1], coord[2], 1.0])
        v = np.round(vox[:3]).astype(int)
        if np.any(v < 0) or np.any(v >= np.array(data.shape)):
            continue
        idx = int(data[v[0], v[1], v[2]])
        if idx > 0:
            return names[idx], 0
        # expanding neighbourhood
        step = float(abs(img.affine[0, 0])) or 2.0
        for radius in (2, 4, max_radius):
            r = int(np.ceil(radius / step))
            lo = np.maximum(v - r, 0)
            hi = np.minimum(v + r + 1, np.array(data.shape))
            block = data[lo[0]:hi[0], lo[1]:hi[1], lo[2]:hi[2]]
            vals = block[block > 0]
            if vals.size:
                mode = int(np.bincount(vals).argmax())
                return names[mode], radius
    return "Unlabeled", -1


def grid_to_mni(i, j, k, perm, signs, bbox):
    """Map patch grid index (centre of cell) to an MNI coordinate under a
    candidate axis permutation/flip."""
    # centre of each cell in [0,1]
    frac = np.array([(i + 0.5) / 4.0, (j + 0.5) / 4.0, (k + 0.5) / 4.0])
    f = frac[list(perm)]
    f = np.where(np.array(signs) < 0, 1.0 - f, f)
    lo = np.array([bbox[0][0], bbox[1][0], bbox[2][0]])
    hi = np.array([bbox[0][1], bbox[1][1], bbox[2][1]])
    return lo + f * (hi - lo)


def main():
    print(BAR)
    print("STEP 4 - HARVARD-OXFORD LABELS FOR THE 20 CONSENSUS PATCHES")
    print(BAR)

    try:
        cort, sub, image = load_atlas()
    except Exception as e:
        print("[FATAL] Could not load the Harvard-Oxford atlas: %s" % e)
        print("        pip install nilearn nibabel   (needs internet once)")
        sys.exit(1)
    print("Atlas loaded: cort-maxprob-thr25-2mm + sub-maxprob-thr25-2mm")

    # MNI152 bounding box of brain tissue (standard, mm)
    bbox = ((-72, 72), (-107, 71), (-60, 85))   # x=L->R, y=P->A, z=I->S

    print("\n--- calibrating grid->MNI mapping against your 5 known labels ---")
    best = None
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product([1, -1], repeat=3):
            hits = []
            for p, want in KNOWN.items():
                i, j, k = patch_ijk(p)
                xyz = grid_to_mni(i, j, k, perm, signs, bbox)
                lab, _ = label_at_mni(xyz, cort, sub, image)
                ok = want.lower() in lab.lower()
                # hemisphere must also agree (x>0 is right in MNI)
                ok = ok and ((xyz[0] > 0) == (hemi(p) == "R"))
                hits.append(ok)
            score = sum(hits)
            if best is None or score > best[0]:
                best = (score, perm, signs)
            if score == len(KNOWN):
                break
        if best[0] == len(KNOWN):
            break

    score, perm, signs = best
    print("best mapping: axis order %s, flips %s -> reproduces %d/%d known labels"
          % (perm, signs, score, len(KNOWN)))

    if score < 4:
        print("\n[STOP] The mapping could not reproduce your known labels.")
        print("       Do NOT use any labels from this run. Instead, re-run")
        print("       your own Section 3.7.5 labeling script on the full")
        print("       consensus list: %s" % CONSENSUS)
        sys.exit(2)
    if score < len(KNOWN):
        print("       (partial match - treat the output as provisional and")
        print("        cross-check against your own labeling script)")

    print("\n" + BAR)
    print("LABELS FOR ALL 20 CONSENSUS PATCHES")
    print(BAR)
    print("  patch | (i,j,k)   | hemi | MNI (x,y,z)        | radius | label")
    print("  ------+-----------+------+--------------------+--------+------")
    for p in CONSENSUS:
        i, j, k = patch_ijk(p)
        xyz = grid_to_mni(i, j, k, perm, signs, bbox)
        lab, rad = label_at_mni(xyz, cort, sub, image)
        flag = ""
        if p in KNOWN:
            flag = "  <- known: %s" % ("MATCH" if KNOWN[p].lower() in lab.lower()
                                       else "MISMATCH")
        print("   %4d | (%d, %d, %d) |  %s   | (%6.1f,%6.1f,%6.1f) | %5s  | %s%s"
              % (p, i, j, k, hemi(p), xyz[0], xyz[1], xyz[2],
                 ("centre" if rad == 0 else "%dmm" % rad), lab, flag))

    print("\nPriority for the manuscript: patches 10, 30, 5 (10 is the new top")
    print("biomarker; 30 and 5 are the three-cohort survivors).")
    print("\nDone.")


if __name__ == "__main__":
    main()
