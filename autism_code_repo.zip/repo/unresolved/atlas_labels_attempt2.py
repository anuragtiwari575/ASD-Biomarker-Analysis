# -*- coding: utf-8 -*-
"""
step4b_labels.py - Harvard-Oxford labels, second attempt.

WHAT CHANGED vs step4_labels.py
  1. Volumetric, not point-based. Each patch is a 32x32x32 block of the
     128^3 grid; we take the MODAL atlas label over the whole block and
     also report the runner-up with coverage percentages. This matches how
     a ~175 cm^3 patch actually behaves and is far more stable than
     querying a single centroid voxel.
  2. Only 4 orientations tested, not 48. Your Methods fix the axis roles
     (i = superior-inferior, j = anterior-posterior, k = left-right with
     k in {0,1} = left), so the only unknowns are whether i and j run
     forwards or backwards. Testing 4 candidates instead of 48 removes the
     multiple-comparisons problem of "some mapping will fit by chance".
  3. FULL DIAGNOSTICS. For every orientation it prints which of your five
     published labels match and which don't. This matters because the old
     consensus bookkeeping was buggy -- so a mismatch may mean the
     PUBLISHED label is wrong, not the mapping. You need to see which.

REQUIREMENTS:  pip install nilearn nibabel
RUN:           python step4b_labels.py > labels2.txt 2>&1
"""

import sys

import numpy as np

CONSENSUS = [10, 46, 30, 38, 62, 22, 58, 9, 42, 26, 39, 27, 23, 43,
             6, 14, 5, 57, 49, 41]

# published labels, used as diagnostics only (they may themselves be stale)
KNOWN = {
    46: "frontal pole",
    58: "precentral",
    39: "postcentral",
    42: "middle frontal",
    43: "white matter",
}

BAR = "=" * 72
G = 4          # grid is 4x4x4
N = 128        # resampled volume is 128^3
B = N // G     # 32 voxels per patch per axis


def ijk(p):
    return p // 16, (p % 16) // 4, p % 4


def hemi(p):
    return "R" if p % 4 >= 2 else "L"


def build_label_volume():
    """Resample the Harvard-Oxford atlases onto a 128^3 grid covering the
    MNI brain, with array axes ordered (SI, AP, LR) to match the patch
    indexing. Cortical labels take precedence; subcortical fills gaps."""
    from nilearn import datasets, image
    import nibabel as nib

    cort = datasets.fetch_atlas_harvard_oxford("cort-maxprob-thr25-2mm")
    sub = datasets.fetch_atlas_harvard_oxford("sub-maxprob-thr25-2mm")

    def as_img(a):
        return a.maps if hasattr(a.maps, "get_fdata") else nib.load(a.maps)

    cimg, simg = as_img(cort), as_img(sub)
    cdat = np.asarray(cimg.get_fdata()).astype(int)
    sdat = np.asarray(simg.get_fdata()).astype(int)
    aff = cimg.affine

    # MNI bounding box of the brain
    xs = np.linspace(-72, 72, N)     # left -> right
    ys = np.linspace(-107, 71, N)    # posterior -> anterior
    zs = np.linspace(-60, 85, N)     # inferior -> superior

    inv = np.linalg.inv(aff)
    # build coordinate grid in (SI, AP, LR) order => axes (z, y, x)
    Z, Y, X = np.meshgrid(zs, ys, xs, indexing="ij")
    ones = np.ones(X.size)
    world = np.vstack([X.ravel(), Y.ravel(), Z.ravel(), ones])
    vox = (inv @ world)[:3]
    vox = np.round(vox).astype(int)
    shape = np.array(cdat.shape)
    ok = np.all((vox >= 0) & (vox < shape[:, None]), axis=0)

    out = np.zeros(X.size, dtype=int)
    vi = vox[:, ok]
    cvals = cdat[vi[0], vi[1], vi[2]]
    svals = sdat[vi[0], vi[1], vi[2]]
    merged = np.where(cvals > 0, cvals, np.where(svals > 0, svals + 1000, 0))
    out[ok] = merged
    vol = out.reshape(N, N, N)   # axes: (SI, AP, LR), SI ascending upward

    names = {}
    for i, nm in enumerate(cort.labels):
        names[i] = nm
    for i, nm in enumerate(sub.labels):
        names[1000 + i] = nm
    names[0] = "Unlabeled"
    return vol, names


def patch_labels(vol, names, flip_i, flip_j):
    """Return {patch: [(label, fraction), ...]} under a given orientation.

    vol axes are (SI ascending, AP ascending, LR ascending = left->right).
    Grid k in {0,1} must be LEFT, so k maps directly to the LR axis.
    flip_i / flip_j decide whether i=0 is inferior or superior, and
    whether j=0 is posterior or anterior.
    """
    res = {}
    for p in range(64):
        i, j, k = ijk(p)
        ii = (G - 1 - i) if flip_i else i
        jj = (G - 1 - j) if flip_j else j
        block = vol[ii * B:(ii + 1) * B,
                    jj * B:(jj + 1) * B,
                    k * B:(k + 1) * B]
        vals = block.ravel()
        vals = vals[vals > 0]
        if vals.size == 0:
            res[p] = [("Unlabeled (outside brain)", 1.0)]
            continue
        cnt = np.bincount(vals)
        order = np.argsort(-cnt)[:3]
        total = block.size
        res[p] = [(names.get(int(o), "?"), cnt[o] / total)
                  for o in order if cnt[o] > 0]
    return res


def score(res):
    hits, misses = [], []
    for p, want in KNOWN.items():
        got = " / ".join(l for l, _ in res[p][:2]).lower()
        (hits if want in got else misses).append(p)
    return hits, misses


def main():
    print(BAR)
    print("STEP 4b - VOLUMETRIC HARVARD-OXFORD LABELS")
    print(BAR)
    try:
        vol, names = build_label_volume()
    except Exception as e:
        print("[FATAL] atlas load/resample failed: %s" % e)
        print("        pip install nilearn nibabel")
        sys.exit(1)
    frac = (vol > 0).mean()
    print("Label volume built: 128^3, %.1f%% of voxels labeled" % (100 * frac))

    print("\n" + BAR)
    print("ORIENTATION DIAGNOSTICS (which published labels each one matches)")
    print(BAR)
    cands = {}
    for fi in (False, True):
        for fj in (False, True):
            res = patch_labels(vol, names, fi, fj)
            hits, misses = score(res)
            tag = "i%s_j%s" % ("rev" if fi else "fwd", "rev" if fj else "fwd")
            cands[tag] = (res, hits, misses)
            print("\n  [%s]  matches %d/5" % (tag, len(hits)))
            for p in sorted(KNOWN):
                got = res[p][0][0]
                second = res[p][1][0] if len(res[p]) > 1 else "-"
                mark = "OK " if p in hits else "XX "
                print("     %s patch %2d  published: %-28s got: %s (%.0f%%) | 2nd: %s"
                      % (mark, p, KNOWN[p], got, 100 * res[p][0][1], second))

    best = max(cands.items(), key=lambda kv: len(kv[1][1]))
    tag, (res, hits, misses) = best
    print("\n" + BAR)
    print("BEST ORIENTATION: %s  (%d/5 published labels reproduced)"
          % (tag, len(hits)))
    print(BAR)
    if misses:
        print("Mismatched patches: %s" % misses)
        print("NOTE: the old consensus table was produced by buggy bookkeeping,")
        print("so a mismatch here may mean the PUBLISHED label was attached to")
        print("the wrong patch ID. Compare the 'got' column above against the")
        print("effect sizes before deciding which to trust.")

    print("\n  patch | (i,j,k)   | hemi | primary label (coverage)      | secondary")
    print("  ------+-----------+------+-------------------------------+----------")
    for p in CONSENSUS:
        i, j, k = ijk(p)
        lst = res[p]
        prim, pf = lst[0]
        sec = ("%s (%.0f%%)" % (lst[1][0], 100 * lst[1][1])) if len(lst) > 1 else "-"
        star = " *" if p in (10, 46) else ""
        print("   %4d | (%d, %d, %d) |  %s   | %-24s %3.0f%% | %s%s"
              % (p, i, j, k, hemi(p), prim[:24], 100 * pf, sec, star))

    print("\n  * = FDR-significant principal biomarker")
    print("\nSanity checks to eyeball before using these:")
    print("  - every patch with k in {0,1} should read 'Left ...' and")
    print("    k in {2,3} should read 'Right ...'")
    print("  - patch 46 should be frontal (it is your most reproducible one)")
    print("  - corner patches (0, 3, 12, 15, 48, 51, 60, 63) should be")
    print("    mostly Unlabeled -- they are the zero-variance background")
    print("    patches that motivated the p=1.0 rule in Section 3.7.3")
    for p in (0, 3, 15, 60, 63):
        print("       patch %2d -> %s" % (p, res[p][0][0]))
    print("\nDone.")


if __name__ == "__main__":
    main()
